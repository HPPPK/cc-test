This Expert Pack includes an original, self-contained adaptation of selected visual-review principles inspired by pbakaus/impeccable.

Upstream snapshot: 32930818a109fafa87199babe92fa8e530cff5d3 (2026-07-30)
Upstream copyright: Copyright 2025 Paul Bakaus
License: Apache License 2.0 (see LICENSE)
No upstream scripts are embedded or executed by this pack.
