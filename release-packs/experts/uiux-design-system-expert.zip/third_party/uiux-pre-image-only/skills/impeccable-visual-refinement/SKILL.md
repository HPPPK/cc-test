---
name: impeccable-visual-refinement
description: A self-contained, source-preserving visual-refinement pass for screenshot-driven UI work. It establishes a specific visual register, detects generic AI treatments in rendered PNGs, and makes a restrained second-pass revision without external scripts.
---

# Impeccable visual refinement

## Purpose

Use this after the first local PNG has been rendered and Read. This package-local adaptation is inspired by the design-review approach in pbakaus/impeccable. It is self-contained: never call .agents/skills/impeccable, context.mjs, detect.mjs, palette.mjs, npx, or an external Skill runtime. Use only the enabled tools.

This is not a request to make every page look premium. It makes the page recognisably belong to the supplied product, task, and screenshot.

## Required refinement sequence

### 1. Define a visual register before revising

After inspecting the first PNG, define five fields and copy the useful parts into the final review receipt:
- Scene sentence: the concrete product moment. Example: a compact product-internal upgrade window for a recording utility, not a modern SaaS pricing page.
- Source anchors: exactly 2–4 visible traits retained from the screenshot: composition, brand color, density, type rhythm, controls, payment relation, or window chrome.
- One spatial move: a hierarchy/composition choice that follows the source instead of a default centered hero or equal grid.
- One material/type move: one restrained surface, border, shadow, number, or typography treatment with a clear purpose.
- Refusal: one familiar visual lane that this page will not use, such as a generic dark summary card, huge English eyebrow, five equal cards, beige landing shell, decorative icon set, or ungrounded gradient glow.

### 2. Run the anti-slop questions against the rendered PNG

Do not answer from HTML alone. Revise when any answer is yes:
1. With logo/product copy removed, could this sell any unrelated SaaS?
2. Is the first visual move a category reflex: generic hero, symmetric pricing grid, oversized all-caps label, dark premium panel, glow/gradient, or floating icons?
3. Are cards decoration/nesting instead of a real choice, payment, status, or boundary?
4. Is Chinese type and price hierarchy doing meaningful work, rather than merely becoming larger/bolder?
5. Does any color, icon, badge, background word, crown, star, fake device, or texture lack task/source/interaction meaning?
6. On tablet/mobile, did the distinctive action survive, or did the page collapse into generic stacked cards?

### 3. Make a restrained, source-specific second pass

Change HTML instead of piling on decoration. Prefer subtraction and rebalancing. Remove at least one generic treatment visible in the first PNG and make one source-specific refinement.

Hard refusals unless directly required by the source screenshot:
- no giant English eyebrow, background word, or REC spectacle;
- no crown, sparkle, rocket, chart, or random icon used only to signal premium;
- no dark section dropped into an otherwise light/warm UI merely to imply quality;
- no five equal-width/equal-emphasis cards when source decision hierarchy differs;
- no 24px-plus card rounding, border-plus-wide-shadow ghost cards, decorative grid backgrounds, or generic purple/blue AI gradients;
- no invented promotion, segment, trial, refund, savings, or lifestyle-price analogy.

For purchase, membership, or upgrade UI, retain observed commercial facts. Improve selection clarity and payment confidence through source-specific hierarchy, copy rhythm, and composition—not made-up offers or an anonymous pricing page.

### 3a. Run a literal mobile collision check

At 390px, inspect the PNG at native size. Every tier name, cycle, price, badge, CTA, payment label, and account/control must have its own readable rectangle. A sale/ribbon/recommendation badge may not cover the tier name or price, sit in its reading path, or force text below it to clip. If it does, move the badge into normal flow above/beside the copy, shorten only non-factual helper wording, or remove the decoration; then rerender. Never declare the mobile layout finished from CSS intent alone.

### 3b. Keep plan badges in normal document flow

For package/tier/member cards, a promotion, recommendation, or gift badge must not use position:absolute in the final HTML. It creates false confidence in a wide screenshot and regularly covers tier names or prices at 390px. Put the badge as a short normal-flow line above/beside the factual tier copy, or remove it when it is only decoration. Treat a final absolute-positioned plan badge as a visual-QA failure even when the screenshot appears acceptable.

### 4. Prove the refinement in the final receipt

Only after revised desktop, tablet, and mobile PNGs are rendered and Read, include a concise visual-review-receipt with:
- taste-redesign, impeccable-visual-refinement, ui-craft-critique, and ui-craft-finalize;
- visual-register: the scene sentence and source anchors;
- removed: the exact generic treatment removed after PNG inspection;
- screenshot-specific findings for 1440 desktop, 1024 tablet, and 390 mobile, including collision/overlap/cropping review at 390px;
- source facts kept intact and any unverified business assumption.

A name-only claim is not evidence. If anti-slop still fails after the second render, return NEEDS WORK with the remaining visual failure and the one required user decision.

## Screenshot-driven craft acceptance for dense transaction windows

For a screenshot-derived purchase or upgrade window with four or more visible plans, do not accept a recolor of equal-sized pricing cards as the refinement pass. After reading the first PNG, choose and visibly implement one source-compatible hierarchy move: a non-equal selected-plan proportion, a continuous selection-to-checkout alignment, or a compact selector that moves secondary comparison copy outside the option grid. Preserve the source ledger; do not invent a new business offer.

Reject the revision if all plans retain the same apparent width, height, padding, information density, and visual weight except for one colored border or badge. In the final PNG, Chinese type, prices, support copy, and payment action must demonstrate separate hierarchy roles. Record the specific generic pattern removed and the screenshot-visible replacement in the visual-review receipt.


## Payment and density finish bar

A payment placeholder is acceptable only when it cannot be mistaken for a working QR or barcode. Prefer a clearly labelled neutral container plus a source-supported login/payment CTA; never use stripes, checkerboards, pseudo-random cells, or black-white matrices to imply scannability.

After removing non-factual lifestyle comparisons, inspect the negative space in every plan card. Empty space must be a deliberate hierarchy signal, not residue from deleted copy. Tighten secondary cards and concentrate visual mass around the selected plan and the real next action. Process disclaimers belong in the delivery notes, never inside the customer-facing render.
