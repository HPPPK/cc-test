---
name: website-reference-research
description: 使用当前真实可用的无头浏览器研究公开设计网站，将多来源可观察规律综合为原创 UI/UX 方向，并处理用户灵感链接与内置来源的去重。
---

# Website Reference Research

## 来源优先级
1. 用户明确提供的 URL、网站或截图；
2. 用户明确选择的来源偏好；
3. 内置参考来源；
4. 在真实 WebSearch 可用时发现并经 Playwright 打开的补充公开 URL。

内置来源是起点，不是强制模板：
- `zcool.com.cn`：中文品牌表达、本地设计语境、视觉风格；
- `land-book.com`：Web 信息区块、落地页、定价、Hero 和 CTA；
- `awwwards.com`：品牌叙事、动效和高视觉表达；
- `dribbble.com`：局部组件构图、版式与视觉细节。

## 研究规则
- 仅使用真实可用的 Playwright 打开公开 http(s) 页面。候选 URL、搜索摘要和记忆都不是证据。
- 每个任务研究最少 2 个、通常不超过 6 个真正打开的页面；选择与页面类型和用户目标相关的来源，而不是为了凑数量。
- 对每个来源记录：实际 URL、页面类型、观察到的规律、可借鉴部分、不采用部分。
- 抽象“规律”，不复制品牌资产、完整布局、文案、插画、图标或受保护作品。
- 研究结果不能证明可用性、商业效果或用户偏好；这些只能作为待验证假设。

## 去重规则
- 对 URL 进行规范化：小写协议/域名、去 fragment、移除默认端口、删除常见追踪参数，并保留必要路径与查询。
- 如果用户提供的 URL 与内置来源同域且已经指定具体页面，优先研究该具体 URL；不要又研究同一来源主页或重复页面。
- 如果一个页面已经被打开并形成观察记录，不要因不同关键词再次打开它；复用既有证据。
- 用户明确说“不使用外部参考”时，完全跳过研究，不要以默认来源补回。

## 输出格式
使用简明来源卡：
| 来源 | 观察到的规律 | 本项目的原创应用 | 不直接复制的内容 |
| --- | --- | --- | --- |

最后说明：研究来源、采用的抽象规律、未验证假设和研究盲区。


## Oversized screenshot fallback

Keep the two initially locked public URLs stable. If Read rejects a Playwright screenshot for exceeding its image dimensions, do not research a new site yet. Use Bash once to create a JPEG/PNG derivative in the exact same directory as the returned screenshot. Its filename must start with the returned source filename before the extension plus a hyphen, for example source-scaled.png. Read that derivative immediately. Do not move/copy the derivative into the session workDir: it loses Playwright provenance and does not count as external visual evidence. Only replace a system-selected URL after its Playwright attempt is actually unavailable or failed. If the user supplied the two locked URLs or explicitly prohibited a third site, never replace either: record the inaccessible URL, do not WebSearch, and continue only with source evidence plus any successfully read locked screenshot.


## 用户锁定 URL 的封闭范围（最高优先级）
用户明确给出两条 URL，或说“不要第三个网站”时，研究范围固定为这两条。不得为了凑数量调用 WebSearch、搜索候选、或打开 Setapp/Stripe/Linear 等替代站。任一锁定页不可访问，只能在收据中记为不可用；它不是视觉证据，也不能被替代站悄悄覆盖。
