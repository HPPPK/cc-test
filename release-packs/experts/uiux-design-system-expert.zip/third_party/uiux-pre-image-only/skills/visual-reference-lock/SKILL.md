---
name: visual-reference-lock
description: 将公开网站灵感研究锁定为真实可见的视觉输入：先选择具体页面，再以 Playwright 截图并 Read 图片，抽象规律而非复制整页。
---

# Visual Reference Lock

## 目的
让网站参考成为模型实际看过的视觉材料，而不是搜索摘要、页面文字或凭记忆的风格名。锁定具体参考站不限制创意；它只禁止用模糊网站名和通用模板替代真实视觉观察。

## 何时使用
- 用户选择使用内置公开参考来源或允许扩展公开网页研究；
- 用户提供可公开访问的灵感 URL；
- 任务需要从公开界面中提炼视觉、信息层级或交互表达规律。

用户明确选择不使用外部参考时，记录该决定并跳过本 Skill；不要假装做过研究。

## 强制顺序
1. 先完成截图事实和灵感来源决定。用户未说明时，必须用 AskUserQuestion 的 inspiration_sources 选择卡询问；不要用文字选项替代。
2. 写一个简短的锁定计划，为当前任务选择两个角色不同的具体公开 URL：结构参考（页面类型接近）与视觉语言参考（密度、品牌气质、编辑节奏、材质或排版接近）。用户给出的 URL 优先；不要只写平台名或大站首页。
3. 对每个锁定 URL，调用 Playwright 时必须传 includeScreenshot: true。
4. Playwright 成功后，从工具结果提取 Local screenshot path，并立即用 Read 读取该 PNG。只读网页文字或摘要不算视觉研究。
5. 每张已读取的网页截图只记录：3 个真实可见的视觉规律、1 个将转译到本项目的抽象规律、1 个明确不复制的元素。
6. 同一规范化 URL 或用户 URL 已覆盖内置来源时只研究一次。Cloudflare、验证码、超时、访问拒绝或无截图均是失败，不得计入来源；换一个具体备用 URL。

## 研究完成条件
除非用户明确拒绝外部研究，或只要求分析而不制作视觉产物，进入方向选择或 HTML 前必须有：
- 2 个不同的成功 Playwright 来源；
- 两次请求均为 includeScreenshot: true；
- 两张外站 PNG 都已用 Read 实际读图；
- 一个 <visual-reference-receipt>，写出 URL、可见规律、原创转译和不复制项。

## 创作边界
- 只借鉴布局关系、层级、字形节奏、信息密度、材质与交互表达规律；不复制品牌资产、受保护插画、整页组合、文案或图标。
- 不把研究过的大站当作审美证明。若截图无法支持某条观察，就标为设计假设。
- 参考存在是创作输入，不是成品质量担保；仍须经过 anti-template-visual-gate 与本地 PNG 复审。
## 参考选择反惯性

先匹配页面类型，再挑风格。锁定 URL 前分别写一句：结构参考为什么与当前容器和交易动作相邻；视觉参考为什么与当前密度、材质、排版或品牌气质相邻。它很流行、它是 pricing page、看起来高级都不是理由。Stripe、Linear 等通用 B2B pricing 页面可作为候选，但当源图为产品内购买弹窗时，二者不能同时成为最终锁定来源，除非用户明确要做 B2B SaaS 定价页。


## Oversized screenshot fallback

Keep the two initially locked public URLs stable. If Read rejects a Playwright screenshot for exceeding its image dimensions, do not research a new site yet. Use Bash once to create a JPEG/PNG derivative in the exact same directory as the returned screenshot. Its filename must start with the returned source filename before the extension plus a hyphen, for example source-scaled.png. Read that derivative immediately. Do not move/copy the derivative into the session workDir: it loses Playwright provenance and does not count as external visual evidence. Only replace a locked URL after its Playwright attempt is actually unavailable or failed; never use a third site as an easier substitute for resizing the first two.


## 用户锁定 URL 的封闭范围（最高优先级）
若用户给出两条具体公开 URL，或明确写出“不找第三个网站”，这两条 URL 是封闭研究范围。先逐条 Playwright(includeScreenshot:true) 并 Read；任何一条失败时，原样记录失败，不得 WebSearch、不得寻找候选、不得替换为第三站。此时仅可使用用户源截图与成功读取的锁定截图作为视觉证据，并在 <visual-reference-receipt> 明确标出研究盲区。该规则覆盖本 Skill 中所有一般性的“换备用 URL”建议。
