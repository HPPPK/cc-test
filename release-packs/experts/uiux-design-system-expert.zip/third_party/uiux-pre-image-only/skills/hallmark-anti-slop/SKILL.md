---
name: hallmark-anti-slop
description: 对已渲染的 UI PNG 执行 Hallmark 反 AI 模板审查：逐项指出可见的命名反模式、修订并再次渲染；不把主观审美判断伪装成自动检测。
source: Nutlope/hallmark@aeb42fb354ff4efa36ab475773a082315a3af2ce
license: MIT
---

# Hallmark Anti-Slop Gate

## 用途与边界

在首轮本地 PNG 已经通过真实 Bash/Playwright 生成且已 Read 后使用。本 Skill 来自 ZIP 内 third_party/hallmark/ 的 MIT 授权 Hallmark 源码；它是命名反模式加截图证据的设计审查法，不是能够客观判定 AI 味的像素分类器。不得说已自动检测无 AI 味；必须说清实际检查的反模式、截图证据、修订内容与盲区。

当真实生图不可用、且用户在 AskUserQuestion 中选择 HTML/CSS 视觉稿时，本 Skill 为强制质量门：HTML/CSS 仍是浏览器渲染的视觉稿，不得称为模型生图或真实图片。

## 先定视觉注册，再检查

在写首版 HTML 前，写出但不要向用户虚构为事实的五项工作底稿：
1. 场景句：具体产品时刻，不用现代 SaaS 页面这种泛称。
2. 截图锚点：2 到 4 个源图可见特征，如窗口语境、密度、色彩、价格/支付关系、控件节奏。
3. 构图动作：一个真实空间层级动作，例如非等宽交易锚点、偏置对齐轴或非均等信息密度。
4. 字体职责：显示字体、正文、数字/价格分别如何承担层级；不能所有文本都用同一系统字体加粗。
5. 色彩锚点：一个有证据或明确标为假设的主色，不用紫蓝或紫粉 Hero 渐变兜底。

## 必查的 Hallmark 命名反模式

逐张 desktop/tablet/mobile PNG 检查并记录通过、命中、证据、修订动作。

### 直接返工的严重项
- 紫蓝或紫粉全屏 Hero 渐变、渐变标题字。
- 白底居中 100vh Hero，只有一句话和一个 CTA。
- 三个完全等宽、等高、图标在上、标题在中、文案在下的功能卡。
- 无语义的 card-in-card、多层圆角白卡与统一阴影。
- 所有页面都落回左 Logo、四个链接、右 CTA 的默认 AI 导航。
- 纯黑/纯白大面积背景、默认 Inter/Roboto/Open Sans 单字体、无层级的数字与价格。
- 同权套餐墙：只靠描边或角标标推荐，但主交易动作没有空间或信息锚点。
- 假二维码、条纹/棋盘格/随机方块扫码图，或把不可用占位冒充可支付二维码。

### 高优先级项
- 厚色侧边条卡片、药丸形 New/Beta 标签、过度统一圆角。
- 任意产品都能套用的无缝、升级、释放、下一代、改变游戏规则文案。
- 四列页脚链接农场、FAQ 手风琴、三卡评价轮播等默认模块链。
- 没有来源的餐饮/咖啡/电影/打车价格类比、伪折扣、伪紧迫感或虚构保障。
- 首轮和终稿的结构只换色、换阴影或换圆角，遮住 Logo 后仍像匿名 SaaS 模板。

## 审查与返工闭环

1. 用 playwright-visual-qc 对实际 HTML 生成 desktop 1440、tablet 1024、mobile 390 PNG，并真实 Read。
2. 与 anti-template-visual-gate、impeccable-visual-refinement、ui-craft-critique 合并审查；本 Skill 补充 Hallmark 的具体命名反模式，不重复声称独立自动检测。
3. 任一严重项，或两个及以上高优先级项命中：必须完整修改 HTML，重新渲染三端并 Read；不能用口头解释、DOM 静态检查或第一张失败 PNG 代替。
4. 二次审查仍无法消除关键问题时，结论必须是 NEEDS WORK，并给出 PNG 路径、命中项和唯一需要用户决定的信息。

## 最终收据

在现有 anti-template-review-receipt 和 visual-review-receipt 中追加 hallmark-anti-slop-receipt：
- visual register：场景句、截图锚点、构图动作、字体职责、色彩锚点。
- Hallmark 反模式表：每项通过/命中、对应 PNG 可见证据。
- 修订前后：至少一个首稿真实可见的模板信号和实际修改。
- 三端 PNG 路径与检查结论。
- 本轮实际使用的 hallmark-anti-slop、anti-template-visual-gate、impeccable-visual-refinement、ui-craft-critique、ui-craft-finalize。

没有真实 PNG、没有逐项证据或没有修订闭环时，不得声称 Hallmark 检查通过。
