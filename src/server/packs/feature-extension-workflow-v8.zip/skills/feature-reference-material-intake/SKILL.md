# Feature Reference Material Intake

Use this skill in the intake stage of a feature extension workflow when the user provides or references materials such as website-reference packages, product-brief packages, HTML prototypes, screenshots, documents, or expert material packages.

Purpose:
Turn reference materials into safe, bounded feature-extension inputs.

## Core Rule

Reference materials are inputs for understanding and mapping. They are not permission to copy another product, brand, code, images, CSS, or proprietary text.

## Supported Reference Sources

Supported sources include:

- `.workflow/intake/expert-runs/<runId>/website-reference/material.json`
- `.workflow/intake/expert-runs/<runId>/product-brief-intake/material.json`
- `.workflow/intake/expert-runs/<runId>/repo-health-check/material.json`
- local markdown/text/HTML requirement files
- pasted feature descriptions
- user-selected existing project context

## Material Selection

If multiple reference materials are available, do not choose silently.

The work-order must record:

- selectedReferenceMaterialIds
- primaryReferenceMaterial
- secondaryReferenceMaterials
- ignoredReferenceMaterials
- reason for each selected or ignored material

If the user has not selected materials, ask with bounded choices before continuing.

## Required Reference Fields In work-order.md

When reference materials are used, work-order.md must include:

- referenceMaterials
- selectedReferenceMaterialIds
- primaryReferenceMaterial
- secondaryReferenceMaterials
- ignoredReferenceMaterials
- materialCapabilitySnapshot
- referenceUsageMode
- referencePolicy
- featureMapping
- canReference
- mustReplace
- mustNotCopy
- limitations

## Reference Usage Modes

Ask the user how the material should be used:

1. interaction-pattern
2. layout-structure
3. visual-style
4. product-flow
5. feature-behavior
6. copy-tone-reference
7. not-used

Prefer interaction-pattern for functional replication requests unless the user explicitly asks for layout or visual style.

Do not use unsafe copywriting-reference for competitor, website, or third-party material. Use copy-tone-reference only, and only for tone, information hierarchy, or content structure. Exact text must be replaced.

## Reference Policy

Can reference:

- interaction patterns
- layout structure
- component organization
- user flow
- general visual direction
- feature behavior concepts
- copy tone and information hierarchy

Must replace:

- brand names
- logos
- images
- icons when proprietary
- exact copy
- exact CSS/JS/code
- pricing/customer/legal content
- protected assets

Must not copy:

- source code from reference site
- proprietary imagery
- trademarks
- exact text from competitor/reference pages
- private content
- paywalled or login-only content without user-provided export

## Feature Mapping

Map each reference concept to the target project:

- referenceFeature
- targetProjectFeature
- whatToImplement
- whatNotToImplement
- affectedTargetAreas
- acceptanceCriteria

## AskUserQuestion Requirement

Ask the user to confirm how reference material should be used before implementation planning continues.

Do not proceed if:

- the user asks to copy protected assets
- multiple materials exist but no material selection was confirmed
- the reference material is unreadable
- the target mapping is unclear
- the reference material conflicts with the user's stated feature goal
