# Feature Guided Finish

Use this skill in the final stage of a feature extension workflow.

Purpose:
End the workflow with a clear status, durable artifacts, verified project memory, and guided next-step choices.

This skill is not allowed to repair, test, preview, or start a follow-up workflow.

## Required Outputs

Write:

- handoff.md
- run-report.md
- project-context.md
- follow-up-decision.md

## Entry Rules

Before finalizing, read:

- work-order.md
- implementation-task-packet.md
- implementation-log.md
- quality-report.md
- run-preview.md when available
- run-report.md when available
- project-context.md when available

If `quality-report.md` is missing or `readyForFinish` is false, do not claim the feature is complete unless the user explicitly chooses to finish with limitations.

## handoff.md Must Include

- finalStatus
- workflowClosureState
- selectedFeatureId or featureGroup
- featureExtensionType
- featureSummary
- referenceMaterialsUsed
- materialCapabilitySummary
- referencePolicyCompliance
- scopeSummary
- changedFiles
- acceptanceCriteriaStatus
- scenarioValidationSummary
- validationSummary
- previewSummary
- residualRisks
- notDone
- limitations
- artifactsWritten
- recommendedNextAction
- userNextActionOptions

## run-report.md Must Include

- stage outcomes
- artifacts produced
- user confirmations
- selected reference materials
- implementation evidence
- validation evidence
- preview status
- known limitations
- final next-action decision
- no automatic follow-up execution

## project-context.md Rules

Update durable project context only with verified project facts.

Do not record uncertain assumptions as completed functionality.

If the feature is incomplete, blocked, paused, or completed with limitations, record that status explicitly.

## Final AskUserQuestion

Ask the user what to do next.

If readyForFinish is true, use options like:

1. Finish this feature extension. Recommended.
2. Continue with another feature.
3. Start debug for an issue found during validation.
4. View final summary or changed files.

If readyForFinish is false or unresolved, use safer options like:

1. Return to validation. Recommended.
2. Finish with documented limitations.
3. Start debug for the issue found.
4. Pause for now.

Do not auto-start another workflow.

## Strict Prohibitions

Do not:

- edit production code
- apply patches
- run tests
- start preview
- perform bounded repair
- install dependencies
- run migrations or seeds
- deploy
- commit
- auto-start follow-up workflow
- leave final status ambiguous
- ask for passive free-form feedback when bounded choices are possible
