# Feature Preview Decision Gate

Use this skill after feature validation evidence exists.

Purpose:
Guide the user through preview and finish decisions instead of leaving the workflow in an ambiguous state.

This skill is not deployment, not full QA, and not final handoff.

## Preview Readiness

Offer preview only when:

- implementation-log.md exists
- quality-report.md has validation evidence
- selectedFeatureId or confirmed feature group is stable
- preview command is available or can be inferred safely
- preview does not require dependency installation, migration, credentials, destructive scripts, or deployment
- any long-running process can be bounded and stopped/cleaned up

If preview is unsafe or unavailable, record the reason and offer finish/continue/debug options instead.

## AskUserQuestion Requirement

After validation, use AskUserQuestion. Do not wait for free-form user input.

The question must summarize:

- what was validated
- what passed
- what failed or was skipped
- whether preview is safe/available
- recommended next action

Offer bounded choices:

1. Start or view local preview. Recommended when preview is safe and visual/user-flow confirmation is valuable.
2. Skip preview and finish. Use when validation is enough or preview is unnecessary.
3. Continue checking this feature. Use when the user wants more validation.
4. Route to debug or Stage 1 if a problem, new bug, or unclear requirement was found.

Explain what happens after each option.

## Preview Evidence

If preview is used, write run-preview.md with:

- previewDecision
- command
- URL or status
- startup logs or error summary
- what was checked
- user confirmation result
- skipped reason when skipped
- stop/cleanup status
- remaining risks

## Ready For Finish Rule

Set readyForFinish = true only when:

- quality-report.md exists
- validation evidence is recorded
- preview decision is resolved
- userNextAction is recorded
- no blocking validation failures remain
- no unapproved scope expansion remains

If the user chooses to continue checking, route to debug, or return to intake, readyForFinish must be false.

## Strict Prohibitions

Do not:

- start unbounded services without controls
- ask the user to manually figure out how to preview
- deploy without confirmation
- claim preview passed when it was skipped
- leave preview process status unclear
- auto-start another workflow
