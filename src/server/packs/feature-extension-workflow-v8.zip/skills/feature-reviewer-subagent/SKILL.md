# Feature Reviewer Subagent

Use this skill after a feature coder subagent completes a task or implementation batch.

Purpose:
Review whether the implementation matches work-order.md and implementation-task-packet.md, stays in scope, respects reference-material policy, and has enough focused validation evidence to move forward.

This reviewer is not full QA and must not modify code.

## Review Inputs

The reviewer must receive:

- work-order.md
- implementation-task-packet.md
- coder result
- changed files or diff summary
- focused validation output
- materialCapabilitySnapshot when reference materials are used
- reference policy when applicable

## Review Questions

1. Does the implementation match the selected featureId or feature group?
2. Does it match the declared featureExtensionType?
3. Does it satisfy relevant acceptance criteria and scenario cases?
4. Are changed files within allowedChangeAreas?
5. Did it touch out-of-scope or do-not-touch areas?
6. Did it use unanalyzed material as source of truth?
7. Did it copy protected reference assets, text, code, brand, logo, CSS, or JS?
8. Are tests/checks sufficient for implementation stage?
9. Are batch dependencies or conflicts unresolved?
10. Is this ready for quality validation?
11. Does it require user confirmation or return to intake?

## Allowed Actions

The reviewer may:

- read artifacts
- inspect changed files/diff
- inspect focused validation output
- write review findings

## Forbidden Actions

The reviewer must not:

- edit files
- apply patches
- run migrations/seeds
- install dependencies
- delete files
- deploy
- perform full QA or preview validation
- create alternative implementation
- approve scope expansion silently

## Required Output

Return a Feature Reviewer Report:

- verdict: pass | needs-changes | blocked | return-to-intake | needs-user-confirmation
- selectedFeatureId or featureGroupId
- batchId
- scopeCompliance
- acceptanceCriteriaAlignment
- referencePolicyCompliance
- materialCapabilityCompliance
- validationEvidence
- dependencyConflictAssessment
- issuesFound
- requiredAction
- limitations
