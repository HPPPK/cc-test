# Feature Validation Bounded Repair

Use this skill only inside the feature quality validation stage when validation finds a small issue directly caused by the current feature implementation.

Purpose:
Allow a tightly scoped correction without turning Stage 3 into a second implementation phase.

## Entry Requirements

Bounded repair may be considered only when:

- quality validation has produced a concrete failing check
- the failing check is tied to the current selectedFeatureId or confirmed feature group
- the problem is directly caused by the current implementation
- the correction is small and inside confirmed allowedChangeAreas
- the correction does not require new product decisions
- the correction does not require dependency installation, migration, seed, delete, deploy, credentials, or external services

## User Confirmation

If bounded repair changes code, use AskUserQuestion first.

The question must include:

- failing validation item
- evidence
- proposed bounded repair scope
- files or areas that may change
- why this is not a new feature or unrelated bug
- what happens if the user declines

Options should include:

1. Allow this bounded repair. Recommended when scope is clearly safe.
2. Do not repair; return to implementation or Stage 1.
3. Treat this as a bug and route to debug.
4. Pause and let the user decide later.

## Repair Limits

The workflow must not impose a fixed parallel subagent limit, but it must limit repair scope.

A bounded repair must not:

- broaden feature scope
- implement unselected features
- fix unrelated bugs
- refactor architecture
- reformat unrelated files
- copy protected reference materials
- install dependencies
- run migrations or seeds
- delete files
- deploy
- commit
- start unbounded services

## Output Requirements

Record every bounded repair attempt in quality-report.md:

- repairAttemptId
- triggeringValidationItemId
- evidence
- userConfirmationStatus
- filesChanged
- reason
- validationAfterRepair
- scopeCompliance
- limitations

If bounded repair fails or reveals a new root cause, stop and route to debug or intake.


## Feature Validation Problem Routing Gate
If any acceptance, scenario, test, build, lint, preview, UI, reference-policy, or material-capability validation fails or is blocked, classify it before deciding the route. Record validationFailureClassification, relationToSelectedFeature, recommendedRoute, routeRationale, userRoutingConfirmation, affectedFeatureId, and evidenceForClassification in quality-report.md. Use feature:validation-problem-routing to decide whether to return to implementation, return to scope/material clarification, route to Debug workflow, ask for environment permission, or accept documented risk. Do not silently continue to finish when critical validation is failed or blocked.
