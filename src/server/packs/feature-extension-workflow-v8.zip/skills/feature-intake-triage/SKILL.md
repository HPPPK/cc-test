# Feature Intake Triage

Use this skill in the first stage of a feature extension workflow.

Purpose:
Convert a user feature request and optional reference materials into a clear, bounded extension request.

## Responsibilities

1. Identify the requested feature or enhancement.
2. Detect whether the user requested multiple independent features.
3. Assign featureIds when multiple features are present.
4. Identify the selected feature or ask the user to choose one.
5. Classify featureExtensionType.
6. Identify target project area, affected pages/modules, and available context.
7. Identify reference materials and whether they can actually be used.
8. Identify missing requirements and blockers.
9. Determine whether the feature request is ready for a scoped work-order.
10. Use AskUserQuestion for confirmation and missing information.

## Feature Extension Types

Classify the request as one of:

- ui-only
- frontend-state
- api-backend
- database-change
- integration
- reference-feature-replication
- configuration-build
- cross-cutting
- unknown

If the type is database-change, integration, cross-cutting, or unknown, record riskFlags and actionsRequiringUserApproval.

## Multi-Feature Policy

If the user requests multiple features, create a featureMatrix:

- featureId
- summary
- targetArea
- dependencyRelation
- estimatedScope
- relationship
- status

Classify relationships as:

- independent
- same-scope-group
- prerequisite
- duplicate
- blocked
- unclear

Default behavior:
Implement only one selectedFeatureId or one confirmed same-scope-group at a time.

Only classify features as same-scope-group when:

- they touch the same target area
- they share one acceptance path
- they can be validated together
- implementing them together does not expand risk
- the user confirms grouping

Do not merge independent features without user confirmation.

## Feature Understanding Checkpoint

Before implementation planning completes, ask the user to confirm:

- feature summary
- featureExtensionType
- selectedFeatureId or same-scope-group
- user goal
- in-scope behavior
- out-of-scope behavior
- allowed change areas
- do-not-touch areas
- reference material usage, when applicable
- acceptance criteria

## Readiness Rules

Set readyForImplementation = true only when:

- feature goal is understandable
- featureExtensionType is recorded
- selectedFeatureId or feature group is clear
- in-scope and out-of-scope are recorded
- allowed change areas and do-not-touch areas are recorded
- acceptance criteria are testable or the limitation is user-approved
- scenario cases exist or the limitation is user-approved
- reference material usage is confirmed or explicitly not used
- user confirmation is recorded

If not ready, ask a structured question.

## Strict Prohibitions

Do not:

- edit production files
- run implementation commands
- install dependencies
- start services
- silently choose among multiple independent features
- silently choose among multiple reference materials
- use reference materials without confirming usage mode
- proceed with vague acceptance criteria unless the user explicitly accepts the limitation
