# Guided User Checkpoints

Use this skill in workflows that require user-facing guidance, confirmation, missing information recovery, scope approval, or next-step decisions.

## Core Rule

Never leave the user guessing what to do next.

When user input, confirmation, permission, scope choice, material-use choice, or next-step decision is needed, use AskUserQuestion with bounded options instead of passive free-form prompting.

Do not merely say "please provide more information" or "tell me if you want to continue". Ask a structured question with choices.

## Required Checkpoint Shape

Every AskUserQuestion checkpoint must include:

1. Current understanding.
2. Why a decision is needed.
3. A recommended option.
4. Two to four options.
5. What happens after each option.

## Use AskUserQuestion When

Use AskUserQuestion for:

- confirming feature understanding
- choosing among multiple requested features
- confirming how reference materials should be used
- deciding whether to proceed with incomplete materials
- approving implementation scope
- approving scope expansion
- approving risky actions
- deciding whether to preview
- deciding whether to finish, continue, debug, or start a follow-up workflow
- handling blocked states

## Default Behavior

Continue automatically only when the next step is safe, scoped, and does not require user judgment.

Ask before:

- code modifications
- scope expansion
- using reference materials in a legally or visually sensitive way
- treating multiple requests as one feature group
- running risky commands
- preview decisions
- final follow-up routing

## Forbidden Patterns

Do not:

- wait silently for the user
- hide a blocked state in narration
- ask vague open-ended questions when bounded choices are possible
- make the user guess whether the workflow is done
- auto-start a different workflow
- treat passive free-text input as the only path forward

## Stage Boundary Rule

At every stage boundary, report:

- what was completed
- current status
- known limitations
- recommended next action
- whether the workflow is continuing automatically or waiting for user confirmation
