# Feature Implementation Task Packet

Use this skill in Stage 2 of a feature extension workflow.

Purpose:
Convert a confirmed work-order.md into bounded, dependency-aware implementation task packets before any code change.

This skill is not an implementation skill. It defines the execution boundary for coder and reviewer subagents.

## Required Inputs

Read work-order.md and extract:

- selectedFeatureId or confirmed featureGroupId
- featureExtensionType
- user goal
- inScope and outOfScope
- allowedChangeAreas
- doNotTouch
- actionsRequiringUserApproval
- acceptanceCriteria
- scenarioCases
- validationPlan
- selectedReferenceMaterialIds when present
- materialCapabilitySnapshot when present
- referenceUsageMode and referencePolicy when present
- featureMapping when reference material is used

If any required input is missing or contradictory, use AskUserQuestion before implementation.

## Required Packet Fields

implementation-task-packet.md must include:

- selectedFeatureId or featureGroupId
- featureExtensionType
- source work-order
- referenceMaterialsUsed
- materialCapabilitySnapshot summary
- referenceUsageMode
- referencePolicy
- featureMapping
- allowedChangeAreas
- doNotTouch
- actionsRequiringUserApproval
- acceptanceCriteria
- scenarioCases
- implementationBatches
- batchDependencyGraph
- parallelizableGroups
- integrationOrder
- per-batch coder task packets
- per-batch reviewer checklists
- focusedValidationTarget
- forbiddenActions
- escalationConditions

## Batch Dependency Rules

Mark batches as dependent when they touch:

- the same file
- shared component state
- shared API boundary
- shared database/data model
- global styles or design tokens
- routing/navigation
- auth/permissions
- config/build files
- generated assets
- reference-material mapping that is not separable

Mark batches as independent only when they can be implemented and reviewed without conflicting file or behavior changes.

Do not impose a fixed maximum number of parallel subagents or batches. The host runtime controls actual concurrency.

## Reference Material Rules

If reference material is used:

- use only analyzed content recorded in materialCapabilitySnapshot
- respect referencePolicy
- do not copy exact text, brand, logo, images, CSS, JS, code, or protected assets
- do not treat screenshots, Figma links, URLs, PDFs, or uploaded files as understood unless the material was actually analyzed
- ask the user when reference mapping is ambiguous

## User Confirmation Rules

Use AskUserQuestion before editing if the task packet:

- expands scope beyond work-order.md
- adds new allowedChangeAreas
- changes featureExtensionType
- introduces dependency installation
- introduces migration/seed/database change
- requires lockfile regeneration
- uses a reference material not selected in Stage 1
- changes referenceUsageMode
- creates product-impacting implementation alternatives

## Output Rule

The task packet is a gate. No code change may happen before implementation-task-packet.md exists.
