# Feature Coder Subagent

Use this skill when the feature implementation stage dispatches coder subagents.

Purpose:
Apply one bounded feature implementation task from implementation-task-packet.md.

This is not a general autonomous developer. It must not choose unrelated product direction.

## When To Use

Use coder subagents when:

- work-order.md is confirmed
- implementation-task-packet.md exists
- the assigned batch has a bounded task packet
- batch dependencies are clear
- acceptance checks are known
- allowedChangeAreas and doNotTouch are explicit

Parallel coder subagents are allowed when task packets are independent. Do not impose a fixed numeric concurrency limit; host runtime decides scheduling.

## Coder Task Packet Must Include

- selectedFeatureId or featureGroupId
- featureExtensionType
- batchId
- user goal
- in-scope behavior
- out-of-scope behavior
- referenceMaterialsUsed
- materialCapabilitySnapshot summary when relevant
- reference usage policy
- allowed files/modules/areas
- do-not-touch areas
- acceptance checks
- validation target
- dependencies and conflict boundaries
- forbidden actions
- escalation conditions

## Allowed Actions

A coder subagent may:

- read relevant files
- apply scoped patches
- add or update focused tests
- update small supporting files when required by the selected batch
- run focused checks if permitted
- return implementation evidence

## Forbidden Actions

A coder subagent must not:

- implement unselected features
- expand scope silently
- use unanalyzed material as source of truth
- copy protected reference assets/code/text
- install dependencies
- run migrations or seeds
- delete files
- deploy
- commit changes
- start long-running services
- rewrite architecture
- broadly format unrelated files
- touch do-not-touch areas

## Escalation Conditions

Return to the Stage 2 leader instead of continuing when:

- the task requires files outside allowedChangeAreas
- the reference material is insufficient or ambiguous
- the batch conflicts with another parallel batch
- a migration/install/lockfile change is required
- a product choice must be made
- acceptance criteria are contradictory or not testable

## Required Output

Return a Coder Implementation Result:

- status: completed | blocked | needs-user-confirmation | return-to-intake
- selectedFeatureId or featureGroupId
- batchId
- filesChanged
- changesMade
- acceptanceChecksAttempted
- validationResult
- referenceMaterialsUsed
- referencePolicyCompliance
- scopeDeviations
- blockers
- limitations
