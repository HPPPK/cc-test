# Feature Follow-up Router

Use this skill only in the final stage of a feature extension workflow.

Purpose:
Record the user's next-action decision after feature validation without automatically starting another workflow.

This skill exists to prevent ambiguous endings. It makes the final workflow state explicit and converts the user's choice into a durable follow-up intent.

## Core Rule

Do not auto-start another workflow.

If the user chooses to continue with another feature, start debug, or view more detail, record that choice in `follow-up-decision.md` and stop. The next workflow must be started explicitly by the user or host runtime.

## Required Inputs

Read when available:

- work-order.md
- implementation-task-packet.md
- implementation-log.md
- quality-report.md
- run-preview.md
- handoff.md draft
- run-report.md draft
- project-context.md

## Final Status Classes

Use one of these final status classes:

- completed
- completed-with-limitations
- blocked
- paused
- routed-to-debug
- follow-up-feature-requested
- summary-requested
- cancelled

Do not use vague status labels such as "done maybe", "probably complete", or "finished unless there are issues".

## Required AskUserQuestion

Use AskUserQuestion for final next-step choice.

If `readyForFinish = true`, ask:

"本次功能拓展已经可以收尾。接下来你想怎么处理？"

Options:
1. "结束本次功能拓展。" Recommended.
2. "继续做另一个功能拓展。"
3. "发现问题，转入 debug。"
4. "先查看最终总结 / 修改范围 / 剩余风险。"

If `readyForFinish` is false, missing, or validation is unresolved, ask:

"当前功能拓展还没有完全满足收尾条件。接下来你想怎么处理？"

Options:
1. "返回验证阶段继续检查。" Recommended.
2. "接受当前限制并收尾。"
3. "转入 debug 调查问题。"
4. "暂停，等我确认后再继续。"

## follow-up-decision.md Must Include

- finalStatus
- selectedNextAction
- autoStart: false
- recommendedManualWorkflow
- contextToPassForward
- artifactsToReference
- userChoiceSummary
- unresolvedBlockers
- limitations
- timestamp or run marker when available

## Project Context Rules

Update project-context.md only with verified facts.

Allowed:
- feature implemented and validated
- feature completed with limitations
- reference materials used
- files or modules changed
- known risks
- pending follow-up intent

Forbidden:
- unverified claims that the feature is fully complete
- future workflow results
- assumptions not supported by artifacts

## Strict Prohibitions

Do not:

- edit production code
- apply patches
- run tests
- start preview
- perform repair
- start a debug workflow
- start another feature workflow
- deploy
- commit
- leave final status ambiguous
- ask the user to provide free-form feedback when bounded choices are possible
