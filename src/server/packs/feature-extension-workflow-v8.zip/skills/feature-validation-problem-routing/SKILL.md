# Feature Validation Problem Routing

Use this skill in the feature quality validation stage when tests, scenario checks, acceptance review, preview, UI review, or reference-policy checks fail or are blocked.

Purpose:
Classify validation failures and route them correctly instead of silently continuing to finish or turning validation into a second implementation phase.

## Failure Classification

Classify each failed or blocked validation item as one of:

- implementation-gap: the approved feature behavior was not implemented or was implemented incorrectly.
- scope-ambiguity: the expected behavior or acceptance criteria are unclear.
- plan-defect: the implementation plan or batch split was wrong.
- new-independent-bug: the failure appears unrelated to the selected feature or same-scope group.
- environment-blocker: dependency, config, credential, external service, database, FFmpeg/runtime, or platform issue blocks validation.
- test-infrastructure-issue: the test or validation harness is faulty, flaky, or missing prerequisites.
- reference-policy-risk: implementation may copy or misuse protected reference material.
- material-capability-gap: implementation relied on material that was not actually analyzed or was not usable.
- ui-visual-mismatch: the UI does not match approved UI direction, visual requirements, or preview expectations.
- blocked-unknown: evidence is insufficient to classify safely.

## Routing Rules

- implementation-gap -> return to feature implementation for scoped correction.
- scope-ambiguity -> return to feature intake/scope confirmation.
- plan-defect -> return to implementation planning/task packet revision.
- new-independent-bug -> route to Debug workflow or ask whether to record as known issue.
- environment-blocker -> AskUserQuestion for permission/config/credential, skip with limitation, or block.
- test-infrastructure-issue -> ask whether to fix validation infrastructure, skip the check, or block.
- reference-policy-risk -> return to scope/material usage confirmation or ask user to adjust reference usage.
- material-capability-gap -> return to material intake; do not validate from unavailable screenshots, URLs, Figma links, PDFs, or raw references as if they were understood.
- ui-visual-mismatch -> return to implementation for scoped UI repair if scope is clear; otherwise return to scope/design direction.
- blocked-unknown -> use investigation-only routing or Debug workflow.

## Required quality-report.md Fields

When any validation item fails or is blocked, quality-report.md must include:

- validationFailureClassification
- relationToSelectedFeature
- recommendedRoute
- routeRationale
- userRoutingConfirmation
- affectedFeatureId
- evidenceForClassification
- nextActionIfUserApproves

## AskUserQuestion Requirement

Before returning to implementation, routing to debug, accepting risk, skipping checks, or changing scope, ask the user with bounded options.

Example options:

1. Return to implementation for a scoped fix.
2. Return to scope/material clarification.
3. Route this as a Debug workflow issue.
4. Accept documented limitation and continue to finish.

Do not silently continue to finish when required validation failed or was blocked.

## Strict Prohibitions

Do not:
- perform broad repair inside validation;
- fix unrelated bugs as part of the feature extension;
- validate from unavailable or unanalyzed material as if it were reliable;
- hide failed or skipped checks;
- enter finish while critical acceptance, reference-policy, or scenario failures remain unresolved unless the user explicitly accepts documented risk.
