# Feature Scope Work Order

Use this skill to generate the stage-1 work-order.md for feature extension.

Purpose:
Create a bounded, user-confirmed work order that can be safely implemented by later stages.

## Required work-order.md Sections

work-order.md must contain:

- Feature Summary
- Feature Matrix
- Selected Feature / Feature Group
- Feature Extension Type
- User Goal
- Current Project Context
- Source Materials
- Reference Materials
- Selected Reference Material IDs
- Primary Reference Material
- Secondary Reference Materials
- Ignored Reference Materials
- Material Capability Snapshot
- Reference Usage Mode
- Reference Policy
- Feature Mapping
- In Scope
- Out Of Scope
- Allowed Change Areas
- Do Not Touch
- UI / UX Notes
- Data / API / State Notes
- Risk Flags
- Actions Requiring User Approval
- Acceptance Criteria
- Scenario Cases
- Implementation Batches
- Validation Plan
- User Confirmation Status
- Ready For Implementation
- Limitations

## Acceptance Criteria

Acceptance criteria must be testable. Avoid vague criteria such as "looks good", "works properly", or "complete".

Scenario cases should use Given / When / Then when possible:

- Given ...
- When ...
- Then ...

If the available material is insufficient to write testable criteria, record the gap and ask the user to confirm or provide details.

## Implementation Batches

Batches must be high-level, scoped, and dependency-aware. Stage 1 must not create detailed file-level patch instructions.

The workflow must not impose a fixed maximum number of batches or subagents. Concurrency is controlled by the host runtime.

Each batch should include:

- batchId
- goal
- allowedAreas
- expectedFilesOrModules
- acceptanceChecks
- dependencies
- canRunInParallelWith
- risks

## Scope Gate

Before leaving intake, ask the user to confirm the work-order.

Recommended options:

1. Confirm this scope and continue.
2. Add details or reference materials first.
3. Change selected feature or split features.
4. Pause.

## Strict Prohibitions

Do not:

- include broad product redesign unless requested
- include unrelated cleanup
- include detailed patch plans
- allow reference materials to override user requirements
- silently choose among multiple reference materials
- propose copying protected assets, exact text, CSS, JavaScript, or code
- mark readyForImplementation without user confirmation
