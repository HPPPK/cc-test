# Feature Quality Validation Gate

Use this skill in the quality stage of a feature extension workflow.

Purpose:
Validate that the implemented feature satisfies the confirmed work-order, respects reference-material constraints, and does not break adjacent behavior.

This skill is not for broad repair, new feature implementation, or final delivery.

## Required Inputs

Read before validation:

- work-order.md
- implementation-task-packet.md
- implementation-log.md
- project-context.md and run-report.md when useful
- run-preview.md only if a previous preview exists

Do not validate a different feature than the selectedFeatureId or confirmed same-scope feature group.

## Entry Gate

Begin validation only when implementation-log.md records readyForQualityValidation = true.

If readyForQualityValidation is false or missing, do not continue silently. Use AskUserQuestion or return to implementation.

## Validation Matrix

Create a validation matrix with:

- validationItemId
- source: acceptanceCriteria | scenarioCase | referencePolicy | regressionRisk | buildCheck | lintCheck | typecheck | previewCheck
- expectedResult
- checkMethod
- commandOrManualCheck
- actualResult
- status: pass | fail | blocked | skipped | not-applicable
- evidence
- limitation
- owner: leader | qa-subagent | reviewer-subagent | user-preview

## Required Validation Areas

Validate relevant items from:

1. Acceptance criteria from work-order.md.
2. Given/When/Then scenario cases from work-order.md.
3. Feature mapping from reference materials, when applicable.
4. Reference policy compliance, when reference materials were used.
5. Material capability limitations from materialCapabilitySnapshot.
6. Build/typecheck/lint/test signals when relevant and safe.
7. Adjacent regression risks listed in work-order.md or implementation-task-packet.md.
8. Reviewer findings from implementation-log.md.

## Reference-Material Validation

When reference materials were used, verify:

- selectedReferenceMaterialIds match the work-order
- only analyzed materials were used as source of truth
- materialCapabilitySnapshot limitations were respected
- exact text, brand, logo, images, CSS, JS, code, protected assets, pricing, customer claims, or legal content were not copied
- referenceUsageMode was followed
- featureMapping is implemented using the target project's own content and components

If reference-policy compliance is unclear, ask the user instead of approving silently.

## Subagent Use

QA and code-review subagents may be used when checks are independent.

Do not impose a fixed numeric parallelism limit. The host runtime controls actual concurrency.

Each subagent must receive a bounded validation packet that names:

- selectedFeatureId or featureGroupId
- acceptance criteria to validate
- scenario cases to validate
- relevant changed files or modules
- reference policy constraints when applicable
- forbidden actions
- required output format

## Bounded Repair Rule

Bounded repair is allowed only when all are true:

- the failure is directly caused by the current feature implementation
- the cause is obvious from validation evidence
- the fix remains within confirmed allowedChangeAreas
- no new requirement or product decision is needed
- no dependency install, migration, seed, delete, deploy, credential, or external service is required
- the user confirms the bounded repair through AskUserQuestion when the repair changes code

If validation reveals a new bug, unclear requirement, new root cause, missing reference material, or scope expansion, route to debug or Stage 1 intake. Do not silently repair.

## Stage Output

quality-report.md must include:

- selectedFeatureId or featureGroupId
- featureExtensionType
- selectedReferenceMaterialIds
- validationMatrix
- acceptanceResults
- scenarioResults
- referencePolicyCompliance
- materialCapabilityCompliance
- buildLintTypecheckResults
- regressionChecks
- qaReviewResults
- codeReviewResults
- boundedRepairAttempts
- previewDecision
- userNextAction
- readyForFinish
- risks
- limitations

## Strict Prohibitions

Do not:

- broaden feature scope
- implement unselected features
- fix unrelated bugs
- copy protected reference materials
- run unconfirmed installs, migrations, seeds, deletes, or deploys
- claim completion without validation evidence
- claim preview passed when preview was skipped
- leave the user guessing next steps


## Feature Validation Problem Routing Gate
If any acceptance, scenario, test, build, lint, preview, UI, reference-policy, or material-capability validation fails or is blocked, classify it before deciding the route. Record validationFailureClassification, relationToSelectedFeature, recommendedRoute, routeRationale, userRoutingConfirmation, affectedFeatureId, and evidenceForClassification in quality-report.md. Use feature:validation-problem-routing to decide whether to return to implementation, return to scope/material clarification, route to Debug workflow, ask for environment permission, or accept documented risk. Do not silently continue to finish when critical validation is failed or blocked.
