# Scoped Feature Implementation

Use this skill in the implementation stage of a feature extension workflow.

Purpose:
Implement only the confirmed work-order scope using implementation-task-packet.md, bounded coder subagents, reviewer subagents, and focused validation evidence.

This skill is not for feature discovery, broad redesign, or full QA.

## Entry Requirements

Before editing code, verify that work-order.md exists and contains:

- readyForImplementation = true
- userConfirmationStatus confirming the selected scope
- selectedFeatureId or confirmed same-scope feature group
- featureExtensionType
- inScope and outOfScope
- allowedChangeAreas
- doNotTouch
- acceptanceCriteria
- scenarioCases
- validationPlan
- actionsRequiringUserApproval

When reference materials are used, also verify:

- selectedReferenceMaterialIds
- primaryReferenceMaterial or secondaryReferenceMaterials
- materialCapabilitySnapshot
- referenceUsageMode
- referencePolicy
- featureMapping

If these are missing or contradictory, do not edit code. Ask the user or return to intake.

## Required Sequence

1. Read work-order.md.
2. Create implementation-task-packet.md.
3. Confirm with AskUserQuestion when the task packet expands or materially changes work-order scope.
4. Dispatch coder subagents using bounded task packets.
5. Dispatch reviewer subagents after each implemented task or batch.
6. Apply only scope-compliant bounded fixes.
7. Run focused validation when safe and available.
8. Write implementation-log.md.
9. Set readyForQualityValidation.

## Concurrency Rule

Do not impose a fixed maximum number of parallel subagents or batches.

The workflow may describe dependencies, conflicts, and parallelizable groups, but the host runtime controls actual concurrency.

Each subagent must still receive a bounded task packet and must obey allowed scope.

## Scope Rules

Allowed:

- implementation batches from work-order.md and implementation-task-packet.md
- files/modules in allowedChangeAreas
- focused tests or fixtures directly tied to acceptance criteria
- minimal adjacent changes needed to compile or integrate

Forbidden:

- independent feature requests not selected
- using unanalyzed material as source of truth
- copying protected material from references
- unrelated refactors
- broad formatting
- dependency installation without user confirmation
- lockfile regeneration without approval
- migrations/seeds without confirmation
- delete/deploy/commit

## Reference Material Rules

When implementing from website, HTML prototype, screenshot, product brief, repo-health, or other expert material packages:

- implement the target feature behavior, not the source site's protected content
- use reference materials only according to referenceUsageMode
- obey Can Reference / Must Replace / Must Not Copy from work-order.md
- record referenceMaterialsUsed in implementation-log.md
- stop and ask when the reference feature cannot be mapped safely to the target project

## Escalation Rules

AskUserQuestion or return to intake when:

- implementation requires scope expansion
- selected reference material is ambiguous
- acceptance criteria conflict
- dependency install or migration is required
- multiple implementation paths have meaningful product impact
- coder/reviewer detects selected feature is underspecified
- batch dependency graph changes due to shared files or conflicts
