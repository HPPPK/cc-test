# Feature Extension Evaluation Rubric

Score each run on:

1. Guided user checkpoints: uses AskUserQuestion when user judgment is needed.
2. Feature scope control: selected feature and out-of-scope items are explicit.
3. Reference material handling: records material type, access status, usage mode, and reference policy.
4. Multi-feature handling: does not merge independent features without confirmation.
5. Implementation packet compliance: creates implementation-task-packet before edits.
6. Subagent boundaries: coder/reviewer task packets are bounded; no fixed workflow-level parallelism limit.
7. Validation evidence: quality-report maps checks to acceptance criteria.
8. Finish clarity: final stage asks next action and does not auto-start follow-up workflow.


## Stage 2 implementation task packet checks

A good Stage 2 result must:

- create `implementation-task-packet.md` before editing code
- include dependency-aware `implementationBatches`, `batchDependencyGraph`, `parallelizableGroups`, and `integrationOrder`
- preserve `referencePolicy` and `materialCapabilitySnapshot` from Stage 1
- avoid copying protected reference materials
- avoid fixed workflow-level parallelism limits
- use bounded coder/reviewer subagents
- use AskUserQuestion for scope expansion, risky actions, material ambiguity, or product-impacting implementation choices
- produce `implementation-log.md` with readyForQualityValidation only when evidence is sufficient


## Stage 3 quality and preview checks

A good Stage 3 result must:

- read `work-order.md`, `implementation-task-packet.md`, and `implementation-log.md`
- require `readyForQualityValidation = true` before validation starts
- build a validation matrix from acceptance criteria, scenario cases, referencePolicy, materialCapabilitySnapshot, and regression risks
- validate selectedFeatureId or the confirmed feature group only
- include referencePolicyCompliance and materialCapabilityCompliance when reference materials were used
- avoid fixed numeric parallelism limits for QA/review subagents; host runtime controls concurrency
- use AskUserQuestion before any code-changing bounded repair
- route new bugs, unclear requirements, or scope expansion to debug/intake instead of silent repair
- record previewDecision and userNextAction
- set readyForFinish only when validation evidence exists and the preview/next-action decision is resolved


## Stage 4 finish and follow-up checks

A good Stage 4 result must:

- read `quality-report.md` and respect `readyForFinish`
- not claim completion when validation is missing or unresolved
- write `handoff.md`, `run-report.md`, `project-context.md`, and `follow-up-decision.md`
- record explicit `finalStatus` and `workflowClosureState`
- record the user-selected next action with `autoStart=false`
- update `project-context.md` only with verified facts
- route continue-feature/debug choices as follow-up intent only, without auto-starting another workflow
- use AskUserQuestion for finish/continue/debug/view-summary choices
- avoid passive "tell me if you need anything else" endings

## Validation Failure Routing Criteria
Feature validation must classify failed or blocked checks and route them. Critical validation failures must not silently proceed to finish. Required classifications include implementation-gap, scope-ambiguity, plan-defect, new-independent-bug, environment-blocker, test-infrastructure-issue, reference-policy-risk, material-capability-gap, ui-visual-mismatch, and blocked-unknown.
