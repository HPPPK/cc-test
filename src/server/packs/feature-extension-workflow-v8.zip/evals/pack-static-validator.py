#!/usr/bin/env python3
import json, zipfile, hashlib, sys
from pathlib import Path

zip_path = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
if zip_path.is_dir():
    print('Run this script against the exported ZIP file.')
    sys.exit(0)

required_skills = [
    'skills/guided-user-checkpoints/SKILL.md',
    'skills/skill-execution-contract/SKILL.md',
    'skills/source-material-intake-router/SKILL.md',
    'skills/feature-reference-material-intake/SKILL.md',
    'skills/feature-intake-triage/SKILL.md',
    'skills/feature-scope-work-order/SKILL.md',
    'skills/feature-implementation-task-packet/SKILL.md',
    'skills/scoped-feature-implementation/SKILL.md',
    'skills/feature-coder-subagent/SKILL.md',
    'skills/feature-reviewer-subagent/SKILL.md',
    'skills/feature-quality-validation-gate/SKILL.md',
    'skills/feature-preview-decision-gate/SKILL.md',
    'skills/feature-validation-bounded-repair/SKILL.md',
    'skills/feature-guided-finish/SKILL.md',
    'skills/feature-follow-up-router/SKILL.md',
]

with zipfile.ZipFile(zip_path) as z:
    names = set(z.namelist())
    missing = [s for s in required_skills if s not in names]
    if missing:
        print('FAIL missing skills:', missing)
        sys.exit(1)
    workflow = json.loads(z.read('workflows/feature-extension-workflow-v8.workflow.json'))
    phases = {p['id']: p for p in workflow['phases']}
    assert 'workflow:guided-user-checkpoints' in phases['feature-memory-plan']['skillBindings']
    assert 'feature:reference-material-intake' in phases['feature-memory-plan']['skillBindings']
    assert 'feature:implementation-task-packet' in phases['feature-implement']['skillBindings']
    assert 'feature:scoped-implementation' in phases['feature-implement']['skillBindings']
    assert phases['feature-implement']['subagentPolicy'].get('maxParallel') is None
    assert 'feature:quality-validation-gate' in phases['feature-quality-preview']['skillBindings']
    assert 'feature:preview-decision-gate' in phases['feature-quality-preview']['skillBindings']
    assert 'feature:validation-bounded-repair' in phases['feature-quality-preview']['skillBindings']
    assert phases['feature-quality-preview']['subagentPolicy'].get('maxParallel') is None
    assert 'feature:guided-finish' in phases['feature-finish-memory']['skillBindings']
    assert 'feature:follow-up-router' in phases['feature-finish-memory']['skillBindings']
    finish_outputs = {a['id'] for a in phases['feature-finish-memory'].get('outputArtifacts', [])}
    assert 'follow-up-decision' in finish_outputs
    assert 'fixedParallelLimit' in json.dumps(workflow)
print('PASS feature extension pack static validation passed.')
