# Guided Feature Extension Workflow Pack

This ZIP is a self-contained workflow pack for guided feature extension.

## Core idea

The workflow does not jump directly from user request to code changes. It uses:

1. feature understanding and reference-material intake,
2. user-confirmed work-order,
3. bounded implementation task packets,
4. coder/reviewer subagents with no fixed workflow-level parallelism limit,
5. quality validation and preview decision,
6. guided finish with explicit follow-up routing and no automatic workflow start.

The host runtime controls actual parallel execution. This pack defines scope, evidence, task-packet, and artifact gates; it does not impose a fixed maximum number of parallel subagents.

## Stages

### 1. Feature Intake + Reference Material Scope Gate

Produces `work-order.md`.

Handles:

- user feature request
- multiple requested features
- featureExtensionType classification
- expert material packages
- website-reference/product-brief/repo-health material.json
- multiple reference material selection
- selectedReferenceMaterialIds / primary / secondary / ignored materials
- materialCapabilitySnapshot for every material
- HTML/text/markdown reference materials
- safe reference usage mode
- reference policy
- in-scope / out-of-scope
- allowed change areas / do-not-touch areas
- risk flags and actions requiring user approval
- testable acceptance criteria
- Given/When/Then scenario cases
- high-level implementation batches

### 2. Scoped Feature Implementation + Task Packet Gate

Produces:

- `implementation-task-packet.md`
- `implementation-log.md`

This stage reads the confirmed `work-order.md`, creates dependency-aware task packets, records reference-material constraints, and only then allows bounded implementation. Parallel batches are allowed when the task packet marks them independent; the host runtime controls concurrency. The workflow does not impose a fixed parallelism limit.

### 3. Feature Quality Validation + Preview Decision Gate v2

Produces:

- `quality-report.md`
- optional `run-preview.md`

Validates acceptance criteria, Given/When/Then scenario cases, reference-policy compliance, materialCapabilitySnapshot limitations, adjacent regression checks, and preview readiness.

This stage does not impose a fixed numeric limit on QA/review subagents; the host runtime controls concurrency. It may use bounded repair only for failures directly caused by the current feature implementation, inside confirmed scope, and after AskUserQuestion confirmation when code changes are involved. New bugs, unclear requirements, reference-policy issues, or scope expansion route back to debug or Stage 1 intake.

After validation, it actively asks the user whether to preview, finish, continue checking, or route to debug/intake.

### 4. Guided Finish + Follow-up Routing Gate v2

Produces:

- `handoff.md`
- `run-report.md`
- `project-context.md`
- `follow-up-decision.md`

This stage checks `quality-report.md` before finalizing. If validation is unresolved or `readyForFinish` is false, it cannot silently claim completion. It asks the user whether to return to validation, finish with documented limitations, route to debug, or pause.

It records the selected next action in `follow-up-decision.md` with `autoStart=false`. Continue-feature/debug choices are routing intent only; no follow-up workflow is auto-started.

## Real bundled skills

All added skills are real files inside this ZIP under `skills/*/SKILL.md`:

- `guided-user-checkpoints`
- `source-material-intake-router`
- `feature-reference-material-intake`
- `feature-intake-triage`
- `feature-scope-work-order`
- `feature-implementation-task-packet`
- `scoped-feature-implementation`
- `feature-coder-subagent`
- `feature-reviewer-subagent`
- `feature-quality-validation-gate`
- `feature-preview-decision-gate`
- `feature-validation-bounded-repair`
- `feature-guided-finish`
- `feature-follow-up-router`


## Final-stage status rules

Stage 4 uses explicit final status classes:

- completed
- completed-with-limitations
- blocked
- paused
- routed-to-debug
- follow-up-feature-requested
- summary-requested
- cancelled

`project-context.md` may contain only verified facts. If a feature is incomplete, blocked, or completed with limitations, that status must be recorded explicitly.

## Reference material policy

Reference materials can guide:

- interaction patterns
- layout structure
- component organization
- user flow
- general visual direction
- feature behavior concepts

They must not be copied as:

- brand names
- logos
- protected images
- proprietary copy
- exact CSS/JS/code
- private or paywalled content

## No external tools bundled

This pack does not add LangGraph, SWE-agent, OpenHands, aider, Semgrep, OSV, Repomix, codebase-memory-mcp, Crawl4AI, or any GitHub-downloaded tool.



## Skill Execution Contract

This pack includes `skills/skill-execution-contract/SKILL.md` as a real packaged skill. Each stage must write a Skill Execution Plan and Skill Execution Evidence in its main artifact. Required and triggered conditional skills must leave output evidence; skipped skills must include reasons; forbidden skills/actions must not be used.

## Stage-local skill execution contract

This pack uses a stage-local skill execution contract. The ZIP may contain many skills, but each stage must plan only over its own declared skill set, mainly the current phase's `skillBindings` and skills explicitly named in that phase. The agent must not scan or list every packaged skill in every stage.

For each stage artifact, the Skill Execution Plan should record required skills, triggered conditional skills, skipped stage-local optional skills, forbidden actions, trigger evidence, and output evidence. Skills packaged in the ZIP but not declared for the current stage are out of stage scope and should not appear in `skillsSkipped`.

## Active Workflow Interaction Contract

This pack enforces an active workflow interaction model.

While the workflow is active, it must not silently stop or wait for arbitrary free-form user input. If the next step requires user judgment, permission, missing information, scope choice, preview feedback, or finish/follow-up selection, the workflow must use `AskUserQuestion` with bounded choices. If no user decision is required, execution should continue automatically until the next `AskUserQuestion`, workflow completion, explicit user pause/exit, or fatal runtime error.

The bundled skill file `skills/active-workflow-interaction-contract/SKILL.md` is a real ZIP entry and is bound to every stage in this workflow.


## Runtime Tool / Language Contract

This pack includes three global workflow skills:

- `workflow:active-interaction-contract`
- `workflow:tool-call-contract`
- `workflow:language-contract`

All workflow stages must use AskUserQuestion with the required `questions` parameter when user input is needed. Stages must not silently wait for free-form input while the workflow is active.

When `submit_phase_completion` is available, phase completion must pass explicit `status`, `handoff`, `rationale`, and `evidence` tool arguments. Stage artifacts and normal assistant prose do not automatically become tool arguments.

If the phase-completion/transition tool is unavailable, the workflow must stop in a blocked state and must not continue into the next stage's actions from the current stage.

User-facing language should follow the configured workflow/UI language. Default to Simplified Chinese when no explicit language is available.

## Feature Validation Routing Update
The quality stage now classifies failed or blocked checks before routing. Implementation gaps return to implementation, scope/material ambiguity returns to intake, independent bugs route to Debug workflow, reference-policy and material-capability risks must be resolved or explicitly accepted.

## Route Decision Contract

This pack uses route-aware stage transitions. A stage may continue to the default next phase, return to an earlier phase, stay in the current phase, record a manual follow-up workflow recommendation, pause, finish, or block. The chosen route must be represented structurally in `handoff.routeRequest` and any AskUserQuestion option that asks the user to choose a route.

User-facing prose such as "return to Stage 4" is not sufficient. The runtime confirmation UI must follow the structured route decision instead of assuming the linear next phase.

## Runtime route alignment

This pack separates phase completion from phase routing. `submit_phase_completion` records the current stage result; non-linear routing such as returning to an earlier phase must use `request_workflow_route` when the runtime provides it. If `request_workflow_route` is unavailable, the workflow must not claim that a non-linear route will occur automatically; it should become blocked/needs_user and record a non-executable `recommendedRoute`.

## Runtime Route Tool Final Alignment

This workflow pack assumes the runtime provides `request_workflow_route` for executable same-workflow routing.

Supported route intents:

- `advance`
- `rework_current_phase`
- `jump_to_phase`
- `pause`
- `resume`
- `finish`

`submit_phase_completion` remains a completion-record tool and must not be used to jump to arbitrary phases.

Automatic cross-workflow switching is not executable in the current runtime. When a different workflow is recommended, the workflow should record a manual follow-up recommendation rather than claiming an automatic workflow switch.

AskUserQuestion route options should use structured action metadata; labels alone are not executable workflow actions.

## Submit Phase Completion Failure Recovery

This pack requires every phase boundary to handle `submit_phase_completion` failures safely. Malformed tool arguments must be corrected and retried once. If completion or routing is unavailable, forbidden, rejected, or mismatched, the workflow must stop in the current phase as blocked/needs_user. It must not execute next-stage actions, ask the user to start the next stage, or treat typed `continue` as a phase transition.

`submit_phase_completion` records phase completion. `request_workflow_route` handles runtime-approved routing. Ordinary text and artifact files do not automatically become tool parameters.
