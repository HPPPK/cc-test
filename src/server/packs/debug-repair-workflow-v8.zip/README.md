# Guided Debug Workflow Pack

This workflow pack contains a self-contained guided debug workflow.

The pack is data only. It contains workflow JSON, packaged skills, permissions, model capability requirements, and checksums. It does not execute files inside the ZIP by itself.

## Workflow

Entrypoint:

- `workflows/debug-repair-workflow-v8.workflow.json`

Workflow phases:

1. `debug-memory-intake` — **Debug Intake Gate / 调试入口确认**
   - Confirms the user's bug description before investigation.
   - Uses `AskUserQuestion` instead of passive free-form waiting.
   - Handles multiple reported issues through an issue matrix and selected issue gate.
   - Produces `debug-context.md`.

2. `debug-investigate` — **Root-Cause Investigation / 根因调查**
   - Performs read-only, evidence-backed root cause investigation.
   - May use read-only investigator subagents.
   - Does not edit code.
   - Produces `problem-report.md`.
   - Enters repair only when `readyForFix = true` and the user confirms repair.

3. `debug-fix` — **Scoped Fix Execution / 有边界的最小修复**
   - Requires `problem-report.md` with `readyForFix = true`.
   - Creates `fix-task-packet.md` before code changes.
   - Applies only the smallest scoped fix.
   - May use a bounded coder subagent and a read-only fix reviewer subagent.
   - Produces `fix-log.md`.
   - Enters quality validation only when `readyForQualityValidation = true`.

4. `debug-quality-preview` — **Quality Validation + Preview Decision / 质量验证与预览决策**
   - Validates the selected issue or proven same-root-cause issue group.
   - Runs relevant checks only.
   - Allows at most one confirmed bounded repair attempt.
   - Asks the user whether to preview, finish, continue checking, or start another debug.
   - Produces `quality-report.md` and optionally `run-preview.md`.

5. `debug-finish-memory` — **Guided Finish + Follow-up Gate / 引导式收尾与后续选择**
   - Produces `handoff.md`, `run-report.md`, and `project-context.md`.
   - Ends with explicit `AskUserQuestion` next-action options.
   - Never auto-starts a follow-up workflow.

## Packaged Skills

All skills used by the workflow are packaged as real files inside this ZIP under `skills/*/SKILL.md`.

Guided workflow skills:

- `skills/guided-user-checkpoints/SKILL.md`
- `skills/debug-intake-triage/SKILL.md`
- `skills/root-cause-investigation/SKILL.md`
- `skills/debug-investigator-subagent/SKILL.md`
- `skills/scoped-debug-fix/SKILL.md`
- `skills/fix-coder-subagent/SKILL.md`
- `skills/fix-reviewer-subagent/SKILL.md`
- `skills/debug-quality-validation-gate/SKILL.md`
- `skills/debug-preview-decision-gate/SKILL.md`
- `skills/debug-guided-finish/SKILL.md`

Bundled superpowers skills are also packaged as real files under `skills/superpowers-*`.

## External Tools

No external GitHub project or runtime dependency is bundled or required by this modification.

Not bundled:

- LangGraph
- SWE-agent
- OpenHands
- aider
- Semgrep
- OSV-Scanner
- Repomix
- Gitingest
- codebase-memory-mcp
- Crawl4AI

The workflow only references host tools declared by the host environment, such as `Agent`, `AskUserQuestion`, `Bash`, `apply_patch`, `artifact`, `build`, `lint`, `read`, and `test`, subject to the phase-level permissions in `permissions/permissions.json`.

## Core Interaction Principle

The workflow must not leave the user guessing what to do next.

Whenever user judgment, missing information, permission, scope approval, preview decision, or finish decision is needed, the workflow must use `AskUserQuestion` with bounded options. Use recommendations only when appropriate; factual confirmation and issue-selection options must stay neutral.

Do not replace these gates with passive messages such as "please provide more information" or "tell me if you need anything else".

## Multi-Issue Policy

If the user reports multiple bugs or symptoms:

- Stage 1 creates issue IDs.
- Stage 2 determines whether issues are independent, duplicate, same-root-cause, blocked, or unclear.
- Stage 3 may repair only one selected issue or one same-root-cause issue group at a time.
- Independent new bugs must be handled as a separate debug run or explicit follow-up choice.

## Artifact Chain

The intended artifact chain is:

```text
debug-context.md
  -> problem-report.md
  -> fix-task-packet.md
  -> fix-log.md
  -> quality-report.md
  -> run-preview.md, when applicable
  -> handoff.md / run-report.md / project-context.md
```

Each stage uses the previous stage artifacts as gates. Repair is not allowed before root cause investigation. Quality validation is not allowed before scoped fix logging. Finish is not allowed before validation and guided next-action selection.

## Packaged Evaluation Assets

This ZIP also contains a lightweight `evals/` folder for regression checks and future prompt optimization:

- `evals/debug-workflow-eval-cases.json`
- `evals/debug-workflow-eval-rubric.md`
- `evals/pack-static-validator.py`
- `evals/pack-static-validation-report.md`

These files are real files inside the ZIP. They do not require external downloads and are not executed by the workflow runtime.



## Skill Execution Contract

This pack includes `skills/skill-execution-contract/SKILL.md` as a real packaged skill. Each stage must write a Skill Execution Plan and Skill Execution Evidence in its main artifact. Required and triggered conditional skills must leave output evidence; skipped skills must include reasons; forbidden skills/actions must not be used.

## Stage-local skill execution contract

This pack uses a stage-local skill execution contract. The ZIP may contain many skills, but each stage must plan only over its own declared skill set, mainly the current phase's `skillBindings` and skills explicitly named in that phase. The agent must not scan or list every packaged skill in every stage.

For each stage artifact, the Skill Execution Plan should record required skills, triggered conditional skills, skipped stage-local optional skills, forbidden actions, trigger evidence, and output evidence. Skills packaged in the ZIP but not declared for the current stage are out of stage scope and should not appear in `skillsSkipped`.

## Active Workflow Interaction Contract

This pack enforces an active workflow interaction model.

While the workflow is active, it must not silently stop or wait for arbitrary free-form user input. If the next step requires user judgment, permission, missing information, scope choice, preview feedback, or finish/follow-up selection, the workflow must use `AskUserQuestion` with bounded choices. If no user decision is required, execution should continue automatically until the next `AskUserQuestion`, workflow completion, explicit user pause/exit, or fatal runtime error.

The bundled skill file `skills/active-workflow-interaction-contract/SKILL.md` is a real ZIP entry and is bound to every stage in this workflow.


## Runtime Tool / Language Contract

This pack includes three global workflow skills:

- `workflow:active-interaction-contract`
- `workflow:tool-call-contract`
- `workflow:language-contract`

All workflow stages must use AskUserQuestion with the required `questions` parameter when user input is needed. Stages must not silently wait for free-form input while the workflow is active.

When `submit_phase_completion` is available, phase completion must pass explicit `status`, `handoff`, `rationale`, and `evidence` tool arguments. Stage artifacts and normal assistant prose do not automatically become tool arguments.

If the phase-completion/transition tool is unavailable, the workflow must stop in a blocked state and must not continue into the next stage's actions from the current stage.

User-facing language should follow the configured workflow/UI language. Default to Simplified Chinese when no explicit language is available.

## Validation Failure Routing Update
Stage 4 now classifies validation failures before routing. It does not always return to Stage 1: incomplete same-bug fixes route to Stage 3, wrong root cause routes to Stage 2, independent bugs route to a new Debug intake/workflow, and environment/test blockers ask the user or block.

## Route Decision Contract

This pack uses route-aware stage transitions. A stage may continue to the default next phase, return to an earlier phase, stay in the current phase, record a manual follow-up workflow recommendation, pause, finish, or block. The chosen route must be represented structurally in `handoff.routeRequest` and any AskUserQuestion option that asks the user to choose a route.

User-facing prose such as "return to Stage 4" is not sufficient. The runtime confirmation UI must follow the structured route decision instead of assuming the linear next phase.

## Runtime route alignment

This pack separates phase completion from phase routing. `submit_phase_completion` records the current stage result; non-linear routing such as returning to an earlier phase must use `request_workflow_route` when the runtime provides it. If `request_workflow_route` is unavailable, the workflow must not claim that a non-linear route will occur automatically; it should become blocked/needs_user and record a non-executable `recommendedRoute`.

## Runtime Route Tool Final Alignment

This workflow pack assumes the runtime provides `request_workflow_route` for executable same-workflow routing.

Supported route intents:

- `advance`
- `rework_current_phase`
- `jump_to_phase`
- `pause`
- `resume`
- `finish`

`submit_phase_completion` remains a completion-record tool and must not be used to jump to arbitrary phases.

Automatic cross-workflow switching is not executable in the current runtime. When a different workflow is recommended, the workflow should record a manual follow-up recommendation rather than claiming an automatic workflow switch.

AskUserQuestion route options should use structured action metadata; labels alone are not executable workflow actions.

## Submit Phase Completion Failure Recovery

This pack requires every phase boundary to handle `submit_phase_completion` failures safely. Malformed tool arguments must be corrected and retried once. If completion or routing is unavailable, forbidden, rejected, or mismatched, the workflow must stop in the current phase as blocked/needs_user. It must not execute next-stage actions, ask the user to start the next stage, or treat typed `continue` as a phase transition.

`submit_phase_completion` records phase completion. `request_workflow_route` handles runtime-approved routing. Ordinary text and artifact files do not automatically become tool parameters.


## Submit Failure Recovery Update

This pack forbids direct repair fallback after phase completion failure. If `submit_phase_completion` fails because arguments are malformed, the assistant must correct the input and retry once. If the tool is unavailable, forbidden, mismatched, or still failing, the workflow must block or ask only safe current-phase recovery questions. Debug intake, investigation, validation, and finish stages must never offer `direct repair` as a fallback.
