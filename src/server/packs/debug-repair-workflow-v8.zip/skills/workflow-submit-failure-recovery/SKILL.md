# Submit Phase Completion Failure Recovery

Use this skill in every workflow stage that calls `submit_phase_completion` or reaches a stage boundary.

Purpose:
Prevent the debug workflow from falling back to ordinary chat, direct repair, or next-stage actions when phase completion submission fails.

## Core Rule

A phase boundary is not complete until the runtime has accepted `submit_phase_completion` or has recorded a blocked/needs_user state.

A failed `submit_phase_completion` call must be classified before the workflow does anything else.

Do not ask the user to start investigation, repair, validation, preview, finish, or any next-stage action while the current phase has not completed.

A user's free-text `continue`, `开始`, `继续`, `直接修复`, or similar message is not a substitute for phase completion.

## Mandatory Correctable Retry

If `submit_phase_completion` fails because the tool input is missing or malformed, the assistant MUST correct the tool input and retry the same tool call once before any user-facing fallback.

Correctable examples:
- missing `handoff`
- missing `rationale`
- missing `evidence`
- `handoff` is not an object
- `evidence` is not an array
- malformed `AskUserQuestion` input missing top-level `questions`

Required behavior:
1. Do not ask the user what to do.
2. Do not move to the next stage.
3. Do not offer repair or implementation.
4. Correct the tool input.
5. Retry the same tool call once.
6. If the retry succeeds, continue with normal runtime confirmation.
7. If the retry fails again, stop and mark the stage blocked or needs_user.

## Stale Workflow State

If completion fails because the workflow state version is stale:
1. Refresh or let runtime infer the latest state version when supported.
2. Retry once.
3. If still stale, block and ask the user to refresh or retry the workflow state.

## Non-Recoverable Failures

Do not retry blindly and do not continue to next-stage actions when:
- `submit_phase_completion` is unavailable
- `submit_phase_completion` is not registered
- `request_workflow_route` is unavailable but a non-linear route is required
- the current phase does not match the active runtime phase
- the runtime rejects the transition or route
- the tool is forbidden in the current phase
- permission or workflow state errors persist after one retry
- phase transition mechanism is unavailable

Required behavior:
1. Stop in the current phase.
2. Record `blocked` or `needs_user` status when possible.
3. Explain the blocked reason in user-facing language.
4. Use AskUserQuestion only for safe current-phase choices.
5. Do not perform any target-phase action.

## Debug-Specific No-Direct-Repair Rule

Submit failure is not permission to repair.

In Debug Stage 1, Stage 2, Stage 4, or Stage 5, never offer direct repair as a fallback after phase completion fails.

This remains true even when:
- the bug looks small;
- the fix appears to be one line;
- the user says `继续`, `直接修`, `帮我修`, or similar;
- the assistant believes it already knows the patch;
- the current artifact contains a clear fix idea.

Repair can only happen after the runtime has actually advanced to the scoped repair phase (`debug-fix`) and the current phase permissions expose repair tools.

## Safe AskUserQuestion After Completion Failure

If user input is required after a completion failure, the AskUserQuestion choices must stay within the current phase.

Allowed choices:
- Retry submitting this phase completion.
- View this phase report/artifact.
- Adjust this phase result.
- Pause workflow.
- Exit workflow.

Forbidden choices while still in the current phase:
- Start repair / 开始修复
- Direct repair / 直接修复
- Help me fix now / 直接帮我修
- Start implementation / 开始实现
- Start validation / 开始验证
- Start preview / 开始预览
- Finish workflow / 进入收尾
- Apply code changes / 修改代码
- Run next-stage tools / 执行下一阶段工具

## Required Artifact / Handoff Fields

When a phase completion failure happens, record:

- `phaseCompletionToolStatus`
- `phaseCompletionFailureClass`
- `phaseCompletionRetryCount`
- `lastCompletionError`
- `recoveryActionTaken`
- `nextStageActionsBlocked`
- `directRepairFallbackBlocked`
- `interactionState`

## Strict Prohibitions

Do not:
- continue to the next stage after a failed phase completion;
- ask the user whether to begin the next stage while the current stage is not completed;
- use normal assistant text as a replacement for `submit_phase_completion`;
- use a user's free-text `continue` to bypass phase completion;
- perform investigation, repair, validation, preview, or finish actions inside the wrong phase;
- offer direct repair as a fallback from intake, investigation, validation, or finish;
- treat an unavailable phase completion tool as permission to do the user's requested change manually.

## Interaction With request_workflow_route

`submit_phase_completion` records phase completion.
`request_workflow_route` requests runtime-approved routing such as advancing, reworking the current phase, jumping to a target phase, pausing, resuming, or finishing.

If a non-linear route is required, call `request_workflow_route` when available. If it is not available, mark the phase blocked/needs_user and do not pretend the route will occur.
