# Debug Investigator Subagent

Use this skill only when the debug investigation stage needs focused, read-only investigation lanes.

Purpose:
Dispatch one or more read-only investigator subagents to collect evidence for root-cause analysis.

This skill must never dispatch coder, reviewer, QA, or general autonomous subagents.

## Guided Interaction Requirement

If a subagent needs information or permission outside its bounded task packet, it must return to the Stage 2 leader. The leader must use AskUserQuestion with bounded options. Subagents must not wait for free-form user feedback.

## When To Use

Use a Debug Investigator Subagent when:
- the issue spans multiple possible modules
- frontend and backend could both be involved
- runtime logs, tests, and code paths need separate investigation
- the repository is large enough that one investigator would be inefficient
- there are independent investigation lanes
- there are multiple plausible hypotheses requiring evidence
- multiple reported issues need relation classification without repair

Do not use a subagent when:
- the bug report lacks a recognizable symptom
- critical user information is missing and should be asked first
- the issue is a single obvious compiler error
- the issue is a single missing import or typo
- the investigation lane cannot be scoped
- the stage would need edits or patching to proceed

## Allowed Subagent Actions

A Debug Investigator Subagent may:
- read files
- search files
- inspect logs
- inspect test output
- inspect stack traces
- inspect config files
- inspect existing tests
- run safe existing diagnostic commands if Stage 2 permits them
- return an evidence report

A Debug Investigator Subagent must not:
- edit files
- apply patches
- install dependencies
- run migrations
- run seed scripts
- delete files
- deploy
- start long-running services
- write implementation plans
- create coder task packets
- modify workflow state

## Subagent Task Packet

Every investigator subagent must receive a bounded task packet:

```markdown
# Debug Investigator Task Packet

## Lane
reproduction-lane | stacktrace-lane | codepath-lane | test-signal-lane | config-env-lane | recent-change-lane | integration-lane

## Issue Scope
selectedIssueId or same-root-cause group being investigated.

## Question To Answer
One concrete investigation question.

## Scope
Files, directories, commands, logs, or modules the subagent may inspect.

## Inputs
- debug-context.md summary
- selected issue report
- relevant user report
- relevant logs/test output
- known constraints

## Allowed Actions
- read
- search
- inspect logs
- run safe existing diagnostic command if explicitly allowed

## Forbidden Actions
- no edits
- no patches
- no dependency installs
- no migrations
- no deletes
- no deploy
- no coder subagent
- no broad rewrite

## Required Output
Return an Investigation Lane Report.
```

## Investigation Lane Report

Every subagent must return:

```markdown
# Investigation Lane Report

## Lane
...

## Issue Scope
...

## Scope
...

## Evidence Found
...

## Evidence Not Found
...

## Hypotheses Tested
- hypothesis:
- result:
- evidence:

## Likely Cause
Only if evidence supports it. Otherwise write Unknown.

## Affected Files
...

## Recommended Minimal Fix Direction
High-level direction only. No patch.

## Limitations
...
```

## Leader Responsibilities

The Stage 2 leader must:
- decide whether subagents are needed
- keep subagent scopes narrow
- merge lane reports into problem-report.md
- resolve conflicts between lane reports
- classify multiple issue relationships when applicable
- ask the user with bounded options when a decision is required
- mark readyForFix=false if evidence is insufficient
- not let subagents perform repairs

The leader owns the final root-cause conclusion. Subagents provide evidence, not final authority.
