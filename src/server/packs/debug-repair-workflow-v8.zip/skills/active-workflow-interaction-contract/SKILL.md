# Active Workflow Interaction Contract

Use this skill in every stage of an active workflow.

## Core Rule

While the workflow is active, the workflow owns the conversation.

The workflow must not silently stop and wait for arbitrary free-form user input.

The workflow may become idle only when one of these states is true:

1. An AskUserQuestion is pending and the workflow is waiting for a structured answer.
2. The workflow is completed.
3. The user explicitly exits or pauses the workflow.
4. A fatal runtime/tooling error prevents safe continuation.

## Continue / Resume Rule

A user clicking a continue/use-result button or selecting a structured "continue" option means the workflow should resume execution, not wait for the user to type "continue" in chat.

After a phase is confirmed, the workflow should continue to the next stage and run until the next valid wait state.

## Phase Transition Safety

If a phase-transition or phase-completion mechanism is unavailable, do not bypass it by continuing work inside the current stage.

Do not interpret a user's free-text "continue" as permission to perform actions that are forbidden in the current stage.

If a required transition cannot be performed, enter a blocked state and explain the missing runtime capability using AskUserQuestion when possible.

## User Interaction Rule

When user input is required, use AskUserQuestion with bounded choices.

Do not ask the user to type open-ended free-form text unless the selected choice explicitly asks them to provide details, logs, screenshots, constraints, or materials.

## Tool Permission Rule

The current phase's allowedActions and forbiddenActions remain binding until the runtime has actually advanced to the next phase.

Do not start implementation, testing, preview, repair, or handoff actions simply because the user typed "continue" if the workflow has not advanced to the corresponding stage.


## Runtime Resume Guard
When the user chooses a stage transition option, the expected behavior is runtime resume: complete the current phase, advance the phase, and continue until the next AskUserQuestion, workflow completion, user exit, or fatal error. If runtime resume is unavailable, block and explain the missing capability. Do not ask the user to type "continue" manually.

## Route-Aware Resume Rule

A continue/use-result button may resume the workflow only along the structured route chosen for that stage.

Do not treat "continue" as a generic instruction to proceed linearly.

If the route decision points to an earlier phase or another workflow, resume there. If no executable route is available, enter a blocked state instead of performing target-stage actions inside the current stage.

## Route-aware waiting rule

If a user choice implies a non-linear route, the workflow must request that route through the runtime route mechanism. If no route mechanism is available, the workflow must become blocked or ask a structured question; it must not continue linearly while saying it will return elsewhere.

## Runtime Route Contract

When the workflow needs to go somewhere other than the normal next phase, it must use `request_workflow_route` if the tool is visible. Supported runtime intents are `advance`, `rework_current_phase`, `jump_to_phase`, `pause`, `resume`, and `finish`.

Cross-workflow automatic routing is not executable by the current runtime. If another workflow is recommended, record it as a manual follow-up recommendation and ask/finish/pause accordingly.

A user-visible statement such as "return to Stage 4" is not enough. The route must be represented by structured AskUserQuestion action metadata or by a `request_workflow_route` tool call. If the runtime route tool is unavailable, block safely and do not execute target-stage actions in the current stage.


## Completion Failure Interaction Guard

When a phase completion or route tool fails, the workflow must not replace the failed transition with a direct next-stage action.

For debug workflows, never ask the user whether to directly repair from an intake, investigation, validation, or finish stage after transition failure. Ask only for current-phase recovery choices or block safely.
