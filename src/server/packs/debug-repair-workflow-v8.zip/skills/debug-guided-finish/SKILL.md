# Debug Guided Finish

Use this skill only in the final finish and handoff stage of a debug workflow.

Purpose:
Close a debug run in a way that is explicit, evidence-preserving, and user-guided.

Core rule:
Never leave the user guessing whether the debug workflow is done, blocked, waiting, or ready for another action.

This skill is not a repair skill, investigation skill, QA skill, or preview skill.

## Responsibilities

1. Read the final workflow artifacts:
   - debug-context.md
   - problem-report.md
   - fix-task-packet.md
   - fix-log.md
   - quality-report.md
   - run-preview.md when available
2. Summarize the selected issue or same-root-cause group that was handled.
3. Summarize the root cause, fix, validation evidence, preview status, risks, limitations, and changed scope.
4. Update run-report.md with a reproducible record of what happened.
5. Update project-context.md with durable project memory that future workflow runs should inherit.
6. Write handoff.md for the user and for future workflow handoff.
7. Ask the user a final structured next-action question.

## Required Finish Gate

At the end of this stage, use AskUserQuestion.

Do not passively say:
- "Let me know if you need anything else."
- "Tell me if you want to continue."
- "You can ask me for another change."

Instead, ask a bounded Finish Confirmation question with clear options.

Recommended question shape:

"This debug run is ready to close. What would you like to do next?"

Options:
1. "Finish this debug run." Recommended.
2. "Debug another issue."
3. "Use this result as the starting point for a feature extension."
4. "Show me the final summary or changed scope first."

If the workflow has unresolved risks or skipped validation, include them in the question before asking for the next action.

## Required Handoff Fields

handoff.md must contain:

- finalStatus
- selectedIssue
- issueRelationship when multiple issues were involved
- rootCauseSummary
- fixSummary
- changedFiles
- validationSummary
- previewSummary
- residualRisks
- limitations
- artifactsWritten
- recommendedNextAction
- userNextActionOptions

## Required Run Report Fields

run-report.md must contain:

- runStatus
- selectedIssue
- user confirmations collected
- investigation summary
- repair summary
- validation summary
- preview decision
- artifacts generated
- skipped checks and why
- unresolved questions
- safe follow-up options

## Required Project Context Fields

project-context.md must preserve durable memory for future runs:

- project facts learned during debug
- important commands or validation notes
- changed files and why
- relevant risks or constraints
- follow-up recommendations
- what future runs should not assume

Do not store transient user chat noise or unsupported guesses as durable context.

## Follow-up Routing Rules

If the user wants to debug another issue:
- do not auto-start the next debug workflow
- ask for confirmation or route only through an explicit user choice
- record the current debug run as closed or handed off

If the user wants feature extension:
- do not auto-start feature workflow
- provide a handoff summary that can be used as input
- require explicit user confirmation before any new workflow begins

If the user asks to inspect the final summary:
- show or open handoff.md / run-report.md
- keep the workflow state explicit

## Strict Prohibitions

Do not:
- edit production code
- apply patches
- run tests
- start preview servers
- perform bounded repair
- investigate new root causes
- install dependencies
- run migrations or seeds
- delete files
- deploy
- commit changes
- auto-start any follow-up workflow
- silently wait for free-form user feedback
- claim success without noting skipped checks or limitations

This stage is finish, memory, and guided follow-up only.
