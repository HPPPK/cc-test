# Debug Validation Failure Routing

Use this skill in the debug quality validation stage after a scoped debug fix has been applied and validation, tests, review, or preview reveal a problem.

Purpose:
Classify failures discovered after a debug fix and route them to the correct next action. Do not automatically send every failure back to Stage 1, and do not keep patching blindly in the quality stage.

## Failure Classification

Every failed or blocked validation item must be classified as one of:

- same-bug-incomplete-fix: the original bug remains partly unresolved, but the root cause is still plausible.
- root-cause-wrong: Stage 2's root cause appears incorrect or insufficient.
- regression-from-fix: the Stage 3 patch likely introduced a related regression.
- new-independent-bug: the problem appears independent from the selected issueId or approved same-root-cause group.
- environment-blocker: validation is blocked by missing dependency, credential, service, config, database, platform, or permission.
- test-infrastructure-issue: the test/check itself is broken, flaky, missing prerequisites, or not trustworthy.
- unclear: evidence is insufficient to classify safely.

Also record relationToOriginalIssue:

- same-issue
- same-root-cause
- caused-by-fix
- independent
- unknown

## Routing Rules

- same-bug-incomplete-fix -> return to Stage 3 for a bounded correction if the correction is within approved scope and the user confirms.
- root-cause-wrong -> return to Stage 2 for reinvestigation.
- regression-from-fix -> return to Stage 3 if clearly caused by the patch and scoped; otherwise Stage 2.
- new-independent-bug -> ask whether to start a new debug intake, create a new debug workflow, or record as known issue.
- environment-blocker -> AskUserQuestion for credentials/config/permission, skip with documented limitation, or block.
- test-infrastructure-issue -> ask whether to repair test infrastructure, skip the unreliable check, or block.
- unclear -> return to Stage 2 investigation or ask the user for missing evidence.

Do not use Stage 1 again unless the user is describing a new issue, splitting multiple independent issues, or replacing the original bug description.

## Required quality-report.md Fields

When any validation item fails or is blocked, quality-report.md must include:

- failureClassification
- relationToOriginalIssue
- recommendedRoute
- routeRationale
- userRoutingConfirmation
- affectedIssueId
- evidenceForClassification
- nextActionIfUserApproves

## AskUserQuestion Requirement

When the route changes phase, starts a new debug, accepts risk, skips validation, or performs a bounded correction, ask the user with bounded options.

Example options:

1. Return to Stage 3 for a bounded correction.
2. Return to Stage 2 to reinvestigate the root cause.
3. Start a new Debug workflow for the independent issue.
4. Record the issue as known risk and finish this debug.

Do not encode hidden workflow actions in option labels. The runtime must map the selected option to a real phase transition or routing action.

## Strict Prohibitions

Do not:
- treat all validation failures as new bugs;
- treat all validation failures as the same bug;
- return to Stage 1 by default;
- keep editing in Stage 4 without classification and user confirmation;
- fix independent bugs inside the current debug;
- claim final completion while critical validation failures remain unresolved.
