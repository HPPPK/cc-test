# Debug Quality Validation Gate

Use this skill only in the quality validation stage after a scoped debug fix has been applied.

Purpose:
Prove that the selected bug or same-root-cause issue group was fixed and that the scoped patch did not introduce obvious regressions.

This is not an investigation stage and not a feature implementation stage.

## Entry Requirements

Before quality validation starts, read:
- problem-report.md
- fix-task-packet.md
- fix-log.md

Do not run quality validation when fix-log.md is missing or readyForQualityValidation is not true. Ask the user, return to Stage 3, or mark blocked according to workflow controls.

## Required Validation Scope

Validate only the selected issueId or the same-root-cause issue group approved in earlier stages.

Build a validation matrix with:
- target bug check
- focused validation from Stage 3
- adjacent regression checks
- build/typecheck/lint when relevant and safe
- code review or QA review when useful
- preview requirement decision

Do not silently expand to unrelated bugs, features, or broad refactors.

## Quality Evidence Rules

Every quality claim must cite evidence:
- command/check run
- result
- output summary
- affected issueId
- reason the check was selected
- limitation if the check could not run

Do not claim full regression passed unless a full regression suite actually ran and passed.
Do not claim preview passed unless preview actually ran and the user accepted it or a clear automated preview check passed.

## Bounded Repair Rules

Stage 4 may perform at most one bounded repair attempt, and only when all are true:
- validation failure is directly caused by the Stage 3 patch
- the cause is obvious from validation output
- the repair stays within the approved fix scope
- no dependency install, migration, seed, delete, deploy, or long-running service is required
- user confirmation is obtained before the bounded repair

If the failure suggests a new root cause, scope expansion, or independent bug, do not repair in Stage 4. Return to Stage 2 or ask the user.

After any bounded repair, rerun the failing check and at least one adjacent relevant check.

## QA / Review Subagent Rules

A QA or review subagent may be used only for read-only validation and review.
It may inspect:
- problem-report.md
- fix-task-packet.md
- fix-log.md
- changed files/diff
- test/build/lint output
- preview evidence

It must not edit files, apply patches, install dependencies, run migrations, delete files, deploy, or start broad autonomous work.

## Decision Rules

Set readyForFinish = true only when:
- target bug validation passed, or a clear limitation is recorded and accepted
- relevant regression checks passed, or unavailable checks are explained
- no unreviewed scope deviation remains
- no unresolved high-risk blocker remains
- preview is accepted, skipped by user, or documented as not applicable
- user selected a finish/continue decision through AskUserQuestion

Set readyForFinish = false when:
- target validation fails
- bounded repair failed
- regression evidence suggests a new issue
- preview reveals a problem needing repair
- the user requests more checking
- the issue should return to Stage 2 or Stage 3

## Strict Prohibitions

Do not:
- perform broad rewrites
- fix unrelated bugs
- expand scope silently
- install dependencies
- run migrations or seeds
- delete files
- deploy
- commit changes
- start long-running services without explicit bounded preview controls
- claim final completion
- leave the user without a next-action question


## Validation Failure Routing Gate
If any validation, test, review, or preview check fails or is blocked, classify it before deciding the next route. Record failureClassification, relationToOriginalIssue, recommendedRoute, routeRationale, userRoutingConfirmation, affectedIssueId, and evidenceForClassification in quality-report.md. Use debug:validation-failure-routing to decide whether to return to Stage 3 for a bounded correction, return to Stage 2 for reinvestigation, start a new debug intake/workflow for an independent bug, ask for environment permission, or block. Do not return to Stage 1 by default.
