# Guided User Checkpoints

Use this skill in workflows that require user-facing guidance, confirmation, permissions, scope choices, or missing-information recovery.

## Core Rule

Never leave the user guessing what to do next.

When user input is needed, use AskUserQuestion with bounded options instead of passive free-form prompting. Do not merely say "please provide more information" and wait.

## Required Checkpoint Shape

Every checkpoint must include:

1. Current understanding.
2. Why a decision is needed.
3. A recommended next action only when appropriate; for factual confirmation or issue selection, keep option labels neutral.
4. Two to four bounded choices.
5. What happens after each choice.

## Use AskUserQuestion When

Use AskUserQuestion when the workflow needs the user to:

- confirm the workflow's understanding of the bug, feature, or task
- choose among multiple reported issues
- confirm that investigation may start
- approve entering a code-modification stage
- approve scope expansion
- decide whether to continue with incomplete evidence
- decide whether to preview
- decide whether to finish or continue
- provide logs, screenshots, reproduction steps, credentials, environment details, or permissions
- handle a blocked or ambiguous state

## Do Not

Do not:

- passively ask the user to type arbitrary feedback when bounded choices are possible
- leave the user unsure whether the workflow is finished, blocked, waiting, or continuing automatically
- hide a blocked state inside normal narration
- continue into code changes without explicit approval when user permission is required
- ask vague open-ended questions when a structured choice can guide the user

## Completion Rule

At every stage boundary, make the state explicit:

- what was completed
- what is currently understood
- what is still unknown or limited
- what the next action is, and any recommendation when appropriate
- whether the workflow is waiting for user confirmation or continuing automatically

This skill is interaction guidance only. It does not authorize investigation, code edits, deployments, installs, migrations, deletes, or external network use.


## Neutral Fact Confirmation Rule

When the checkpoint asks the user to confirm facts, correct the assistant's understanding, or choose which reported issue is the true target, do not mark any option as Recommended. Recommendations may be used for safety or navigation guidance only, and should be expressed in the question body or metadata rather than as fake label text.
