# Skill Execution Contract

Use this skill to make stage-level skill use auditable without forcing every stage to consider every packaged skill.

Purpose:
Make skill usage explicit, bounded, and checkable. A skill being packaged in the ZIP does not mean it is available to every stage, and a skill listed in `skillBindings` does not mean it already ran.

## Core Rule

A stage may plan only over its declared stage-local skill set.

The stage-local skill set is:
- the current phase's `skillBindings`
- any skills explicitly named in the current phase instructions, execution rules, or artifact template
- global workflow control skills that are intentionally bound to the current phase, such as `workflow:guided-user-checkpoints` and `workflow:skill-execution-contract`

Do not scan, enumerate, evaluate, or mention all packaged skills in the ZIP.
Skills packaged in the ZIP but not declared for the current phase are out of stage scope and should not be listed as skipped.

## Four-Layer Contract

### Layer 1: Stage-Local Skill Plan

At stage entry, write a Skill Execution Plan in the stage artifact.

The plan must include only the current stage's local skill set:

- Required Skills
- Conditional Skills Triggered
- Optional Skills Skipped
- Forbidden Skills / Forbidden Actions
- Trigger Evidence

Do not create a global inventory of every packaged skill.
Do not add unrelated skills to the plan merely because they exist in the ZIP.

### Layer 2: Trigger Conditions

For every conditional skill declared for this stage, record:

- the condition that was checked
- whether the condition was true or false
- the evidence for the decision
- whether the skill was triggered or skipped

Do not silently skip a conditional skill when its trigger condition is true.
Do not evaluate conditional skills that are not declared for this stage.

### Layer 3: Output Evidence

Every required or triggered stage-local skill must leave output evidence in the stage artifact.

The artifact must record:

- skillsUsed
- skillsSkipped
- skillOutputChecklist
- triggerEvidence
- limitations

`skillsSkipped` should include only stage-local optional or conditional skills that were considered and skipped. It must not list every unrelated skill packaged in the ZIP.

If a required or triggered skill cannot run because of unavailable tools, unavailable model capability, missing material, or user denial, record the limitation and use AskUserQuestion when user judgment is required.

### Layer 4: Completion Gate

The stage cannot complete unless:

- all required stage-local skills are listed in Skill Execution Plan
- every triggered stage-local conditional skill has output evidence
- every skipped stage-local optional or conditional skill has a reason
- no forbidden skill or forbidden action was used
- completionCriteria confirms the skill outputs that matter for this stage

## Standard Artifact Section

Every stage artifact should include this section:

```markdown
## Skill Execution Plan

### Stage-Local Skill Set
- skill:
  role in this stage:

### Required Skills
- skill:
  reason:
  expected output:

### Conditional Skills Triggered
- skill:
  trigger condition:
  trigger evidence:
  expected output:

### Optional Skills Skipped
- skill:
  reason:

### Forbidden Skills / Actions
- item:
  reason:

## Skill Execution Evidence

### skillsUsed
- skill:
  output fields:
  evidence location:

### skillsSkipped
- skill:
  reason:

### skillOutputChecklist
- required output:
  status: present | missing | not-applicable
  evidence:

### limitations
- ...
```

## Stage-Local Menu Rule

The Skill Execution Plan is not a full skill registry review.
It must not list skills outside the current phase's declared stage-local skill set.

Examples:
- A debug intake stage should not consider coder, reviewer, QA, preview, or brainstorming skills.
- A root-cause investigation stage should not consider coder or patch skills.
- A feature implementation stage should not re-run source-material intake unless new material appears or the task packet explicitly requires it.
- A validation stage should not re-open brainstorming or product scope exploration unless the workflow routes back to the scope stage.
- A finish stage should not consider implementation, investigation, preview, or repair skills.

## AskUserQuestion Rule

If a stage cannot decide whether a stage-local conditional skill should run because user intent, permission, material selection, or scope is unclear, use AskUserQuestion with bounded options. Do not wait for passive free-form user feedback.

## Strict Prohibitions

Do not:

- assume a skill ran because it is listed in skillBindings
- scan or list all packaged skills in every stage
- silently skip a triggered stage-local conditional skill
- complete a stage when required stage-local skill outputs are missing
- hide skill failures in prose
- use forbidden skills or forbidden actions for the stage
- let optional skills override the stage objective or scope
- let brainstorming, UI taste, investigation, coder, reviewer, QA, preview, or finish skills leak into stages where they are not declared
