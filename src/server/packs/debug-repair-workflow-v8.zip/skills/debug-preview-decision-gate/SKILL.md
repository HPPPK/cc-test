# Debug Preview Decision Gate

Use this skill only after debug fix validation when the workflow must decide whether to run preview, skip preview, continue checking, or finish.

Purpose:
Make preview and next-step decisions explicit so the user never has to guess whether the workflow is finished, blocked, or waiting.

## Core Rule

Whenever preview, manual acceptance, finishing, or continuing is a user decision, use AskUserQuestion with bounded options.
Do not passively tell the user to provide feedback in the chat box.

## When To Use

Use this gate after quality validation and before leaving Stage 4.
Also use it when preview cannot run, needs a long-running server, needs credentials, requires network access, or may affect local state.

## Preview Decision Question Shape

The question must include:
- what was validated
- what passed
- what failed or was skipped
- whether preview is safe/available
- recommended next action
- 2 to 4 bounded options
- what happens after each option

Recommended options:
1. Run or open preview when safe and useful. Recommended when UI/user flow changed.
2. Skip preview and enter finish when evidence is sufficient.
3. Continue checking this fix.
4. Start a new debug for another issue or return to investigation when a new issue appears.

## Preview Safety Rules

Before starting preview, confirm:
- command is known
- server can be bounded and stopped
- no dependency install is required
- no migration/seed is required
- no credentials are required unless user confirmed
- no deploy/network side effect is required unless user confirmed

Preview must be started and stopped through workflow-owned controls when available.
If preview cannot be safely run, document why and ask the user whether to skip or provide missing setup.

## Preview Result Rules

Record preview status:
- not-needed
- skipped-by-user
- unavailable
- started-and-stopped
- accepted-by-user
- failed

If preview fails due to an obvious Stage 3 patch issue and bounded repair conditions are satisfied, ask before one bounded correction.
If preview reveals a new root cause or independent bug, return to Stage 2 or start a new debug instead of silently repairing.

## Stage Exit Rule

Do not leave Stage 4 silently.
Before transitioning to finish, ask the user to choose the next action unless the workflow has an explicit prior user confirmation covering the same decision.
