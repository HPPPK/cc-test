# Debug Intake Triage

Use this skill only in the first intake stage of a debug workflow.

Purpose:
Convert the user's bug report, inherited project context, logs, screenshots, test output, and reproduction clues into a structured Debug Context.

This skill is not allowed to investigate root cause or repair code.

## Responsibilities

1. Extract the user's reported symptom.
2. Separate expected behavior from actual behavior.
3. Detect whether the report contains one issue or multiple issues.
4. Record available evidence:
   - logs
   - error messages
   - screenshots
   - test output
   - reproduction steps
   - user description
   - affected page, command, module, route, or feature
5. Inherit useful context from project-context.md and run-report.md when available.
6. Identify missing information that blocks meaningful investigation.
7. Decide whether Stage 2 can start investigation.
8. Ask a structured user question when critical information, confirmation, or issue selection is missing.

## Required Debug Context Fields

The output debug-context.md must contain:

- issueMatrix
- selectedIssueId
- symptom
- expectedBehavior
- actualBehavior
- reproductionStatus
- availableEvidence
- affectedArea
- suspectedEntryPoints
- inheritedContext
- missingInformation
- blockingQuestions
- readyForInvestigation
- userConfirmationStatus
- limitations

## Multi-Issue Rules

If the user reports multiple bugs, symptoms, or failure modes, create issueIds such as BUG-1, BUG-2, BUG-3.

Do not merge multiple bugs into one debug target unless the user chooses to investigate whether they share one root cause.

When multiple issues are detected, use AskUserQuestion:

"You may have described multiple issues. To avoid uncontrolled scope, which one should we handle first?"

Options should be neutral. Do not mark any issue choice as recommended, because Stage 1 is confirming facts rather than steering the user's answer.

Options should include:
1. Handle BUG-1.
2. Handle BUG-2 or another listed issue.
3. Investigate whether the listed issues share one root cause.
4. Pause so the user can rewrite the bug report.

## Debug Understanding Checkpoint

Before leaving Stage 1, confirm the workflow's understanding with AskUserQuestion unless the user already gave an explicit confirmation in the same turn.

The checkpoint must summarize:

- selected issueId
- symptom
- expected behavior
- actual behavior
- available evidence
- affected area
- proposed investigation boundary
- limitations

Neutral checkpoint question:

"I want to confirm the bug before investigation starts. Is this the issue you want me to investigate?"

Options:
1. "Yes, start read-only investigation."
2. "Mostly correct, but I will provide logs, screenshots, or reproduction steps."
3. "No, I want to correct the bug description."
4. "There are multiple issues; help me split them first."

Do not label any Stage 1 factual-confirmation option as Recommended. The workflow may explain consequences or limitations in the question body, but the option labels must remain neutral.

## Intake Readiness Rules

Set readyForInvestigation to true only when there is enough information to begin investigation.

Minimum information usually includes:
- a recognizable symptom, and
- actual behavior, and
- either expected behavior, reproduction clue, error/log/test output, affected area, or inherited context, and
- user confirmation or an explicit user decision to continue with limitations.

If the user only says something like "there is a bug" or "it does not work", do not proceed automatically.

If key details are missing, ask the user a structured question first.

If the user explicitly chooses to continue with incomplete information, write readyForInvestigation as true, but record the limitation clearly.

## Strict Prohibitions

Do not:

- edit files
- apply patches
- run tests
- run broad repository search for root cause
- install dependencies
- run migrations
- delete files
- deploy
- start preview servers
- claim root cause
- propose a fix plan
- dispatch coder subagents
- perform broad repository investigation

This stage is intake only.


## Submit Failure Guard For Intake

If phase completion submission fails in the intake stage, do not downgrade into direct repair.

The intake stage is never allowed to repair code, even for a very small bug.

After a completion failure:
1. Correct malformed completion tool input and retry once when possible.
2. If the phase completion tool is unavailable or still failing, block the workflow or ask only safe current-phase choices.
3. Safe choices are: retry completion, view debug-context, adjust the bug description, pause, or exit.
4. Forbidden choices include: direct repair, start repair, edit code, apply patch, run tests, start investigation without phase transition, or continue to the next stage.
