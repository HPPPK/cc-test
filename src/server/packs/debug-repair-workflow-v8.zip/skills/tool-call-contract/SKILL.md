# Workflow Tool Call Contract

Use this skill whenever a workflow stage uses AskUserQuestion, submit_phase_completion, request_workflow_route, or any structured workflow tool.

## AskUserQuestion Contract

AskUserQuestion must be invoked with the host tool's required top-level `questions` parameter.

Do not present a normal chat paragraph as if it were an AskUserQuestion call.

Minimum shape:

```json
{
  "questions": [
    {
      "id": "confirm_next_action",
      "prompt": "用户需要回答的问题。",
      "choices": [
        { "id": "continue", "label": "继续执行工作流" },
        { "id": "revise", "label": "我要调整当前结果" },
        { "id": "pause", "label": "暂停本次工作流" }
      ]
    }
  ]
}
```

Workflow route options should use stable IDs and structured actions when available:

```json
{
  "id": "return-to-stage4",
  "label": "返回 Stage 4 修复该问题",
  "action": {
    "kind": "workflow-route",
    "intent": "jump_to_phase",
    "targetPhaseId": "delegate-implement"
  }
}
```

The user's visible answer should remain the label; the runtime action should use the structured option ID/action.

## Neutral Fact Confirmation

When confirming facts supplied by the user, keep options neutral.

Do not mark factual confirmation choices as "Recommended" when asking whether the AI understood the user's bug, feature, scope, or selected issue correctly.

Recommendations may be stated in the question body for workflow navigation or safety guidance, but option labels should not imply that the AI's factual interpretation is correct.

## submit_phase_completion Contract

When `submit_phase_completion` is available, ordinary text, handoff.md, problem-report.md, work-order.md, or other artifacts do not automatically become tool arguments.

Before calling `submit_phase_completion`, explicitly construct the full tool input.

Required fields:

- `status`: string, such as `ready`, `blocked`, `needs_user`, or `completed`.
- `handoff`: object. Do not pass only a string.
- `rationale`: non-empty string explaining why the stage completion criteria are satisfied or why it is blocked.
- `evidence`: array. If no evidence is available, pass `[]`; do not omit the field.

Recommended shape:

```json
{
  "status": "ready",
  "handoff": {
    "summary": "本阶段完成了什么。",
    "completedItems": ["..."],
    "keyDecisions": ["..."],
    "evidenceArtifacts": [".workflow/runs/<runId>/..."],
    "remainingRisks": ["..."],
    "nextPhaseInputs": ["..."]
  },
  "rationale": "说明为什么当前阶段已经满足完成条件。",
  "evidence": [
    {
      "kind": "artifact",
      "ref": ".workflow/runs/<runId>/...",
      "summary": "该产物证明了什么。"
    }
  ]
}
```

`submit_phase_completion` is not a phase-routing tool. Do not add arbitrary target phase semantics to it.

## request_workflow_route Contract

Use `request_workflow_route` for runtime-validated workflow routing when it is available.

Supported route intents:

- `advance`
- `rework_current_phase`
- `jump_to_phase`
- `pause`
- `resume`
- `finish`

Minimum shape:

```json
{
  "intent": "jump_to_phase",
  "targetPhaseId": "delegate-implement",
  "rationale": "说明为什么需要回到该阶段。",
  "evidence": [],
  "requireUserConfirmation": true
}
```

Do not request automatic cross-workflow switching through this ZIP. If another workflow is recommended, record it as a manual follow-up recommendation and stop/finish/ask as appropriate.

## Missing Tool Fallback

If `submit_phase_completion` is not available, do not continue to the next stage inside the current stage.

If `request_workflow_route` is required but not available, do not claim that a jump or return will occur.

Use one of these safe outcomes:

- AskUserQuestion explaining that runtime routing is unavailable.
- submit the current stage as `blocked` or `needs_user` with clear evidence.
- record a non-executable manual follow-up recommendation.

Never continue by performing next-stage actions in the current stage.

## Forbidden

Do not:

- call AskUserQuestion without top-level `questions`.
- call submit_phase_completion without `status`, `handoff`, `rationale`, and `evidence`.
- treat artifact text as tool parameters.
- use submit_phase_completion as a substitute for request_workflow_route.
- treat AskUserQuestion labels as executable workflow commands.
- ask the user to type "continue" to recover from missing tooling.


## Phase Completion Error Recovery

If `submit_phase_completion` fails because the tool input is malformed, correct the tool input and retry once.

If `submit_phase_completion` is unavailable, forbidden, mismatched to the active phase, or still failing after one corrected retry, do not continue. Do not offer next-stage actions as AskUserQuestion choices. In debug workflows, do not offer direct repair as a fallback from intake, investigation, validation, or finish stages.

Forbidden fallback labels include `直接修复`, `直接帮你修复`, `开始修复`, `开始实现`, `进入验证`, `进入预览`, and `进入收尾` unless the runtime has actually advanced to the corresponding phase.
