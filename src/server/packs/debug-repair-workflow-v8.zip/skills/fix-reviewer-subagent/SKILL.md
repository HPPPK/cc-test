# Fix Reviewer Subagent

Use this skill only after a scoped debug fix has been applied in Stage 3.

Purpose:
Review whether the applied patch stays within the fix scope and matches the evidence-backed root cause.

This reviewer is not full QA, not regression validation, and not preview validation.
Full regression and preview belong to Stage 4.

## Review Inputs

The Fix Reviewer Subagent must receive:
- `problem-report.md`
- `fix-task-packet.md`
- selected issueId or same-root-cause group
- list of changed files
- diff summary or patch
- coder fix result when available
- focused validation result when available

## Review Questions

The reviewer must answer:

1. Does the patch address the root cause from `problem-report.md`?
2. Does the patch follow `minimalFixStrategy`?
3. Are all changed files within allowed change scope?
4. Did the patch touch do-not-touch files or behaviors?
5. Are there unrelated refactors or formatting changes?
6. Did the patch fix only the selected issueId or approved same-root-cause group?
7. Is the focused validation evidence sufficient for Stage 3?
8. Is the patch ready for Stage 4 quality validation?
9. Should the workflow return to Stage 2, ask the user, or proceed to Stage 4?

## Allowed Actions

The reviewer may:
- read `problem-report.md`
- read `fix-task-packet.md`
- read fix-log draft if available
- inspect changed files
- inspect diff
- inspect focused validation output
- write review findings to Stage 3 leader

## Forbidden Actions

The reviewer must not:
- edit files
- apply patches
- install dependencies
- run migrations or seeds
- delete files
- deploy
- start long-running services
- perform broad investigation
- generate alternative implementation
- run full QA or preview
- commit changes
- approve scope expansion silently
- wait for passive free-form user feedback

## Required Reviewer Output

Return:

```markdown
# Fix Reviewer Report

## Verdict
pass | needs-changes | blocked | return-to-investigation

## Selected Issue
...

## Scope Compliance
...

## Root-Cause Alignment
...

## Minimality
...

## Validation Evidence
...

## Multi-Issue Boundary
Confirm the patch does not fix unselected independent bugs.

## Issues Found
- issue:
- severity: low | medium | high
- evidence:
- recommendation:

## Required Action
proceed-to-stage-4 | small-stage-3-correction | return-to-stage-2 | ask-user

## Limitations
...
```

## Review Gate

The Stage 3 leader may proceed to Stage 4 only if:
- reviewer verdict is `pass`, or
- no reviewer was used and the leader records why review was skipped

If reviewer verdict is `needs-changes`:
- allow only one small Stage 3 correction when the issue is clearly within scope
- otherwise return to Stage 2 or ask the user

If reviewer verdict is `return-to-investigation`:
- do not continue patching in Stage 3
- return to Stage 2
