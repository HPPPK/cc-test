# Scoped Debug Fix

Use this skill only in the scoped repair stage of a debug workflow.

Purpose:
Apply the smallest safe fix for an evidence-backed root cause from `problem-report.md`.

This skill is not for investigation, broad refactoring, feature work, or full QA.

## Entry Requirements

Before any code change, verify that `problem-report.md` exists and contains:

- `readyForFix = true`
- selected `issueId` or same-root-cause issue group
- `rootCause` is not `Unknown` or `Unresolved`
- `confidence` is not `unresolved`
- `affectedFiles` or `affectedModules` are identified
- `minimalFixStrategy` is present
- `doNotTouch` is present or explicitly empty
- limitations are understood

If any requirement is missing, do not edit code.
Use `AskUserQuestion` with bounded options, return to investigation, or mark blocked.

## Required Sequence

1. Read `problem-report.md`.
2. Confirm `readyForFix = true`.
3. Confirm that Stage 3 is fixing only one selected `issueId` or one proven same-root-cause group.
4. Create `fix-task-packet.md`.
5. Define allowed change scope.
6. Define do-not-touch scope.
7. Select focused validation target.
8. Present a Fix Scope Gate with `AskUserQuestion`.
9. Apply the smallest patch only after user approval.
10. Run focused validation when safe and available.
11. Optionally request Fix Reviewer Subagent review.
12. Write `fix-log.md`.
13. Set `readyForQualityValidation`.

## Fix Scope Gate

Before editing code, ask the user to approve the repair scope.

The question must include:
- current root cause
- selected issue or issue group
- allowed files/modules
- do-not-touch areas
- validation target
- recommended option
- clear alternatives

Recommended options:

1. Start the minimal fix. Recommended.
2. Adjust the allowed change scope first.
3. Do not edit code; return to investigation.
4. Pause.

Do not patch before the user approves code changes.

## Fix Task Packet

Before editing code, create a Fix Task Packet with:

- selected issueId or same-root-cause group
- source problem report
- root cause
- confidence
- allowed change scope
- do-not-touch scope
- minimal fix strategy
- expected behavior after fix
- focused validation target
- forbidden actions
- escalation conditions

## Scope Rules

Allowed changes:
- only files/modules listed in `affectedFiles`, `affectedModules`, or allowed scope
- only changes required by `minimalFixStrategy`
- focused regression tests when safe and relevant
- minimal adjacent updates needed to keep code compiling

Forbidden changes:
- unrelated refactor
- broad formatting
- architecture redesign
- dependency installation
- lockfile regeneration unless explicitly required and approved
- database migrations
- seed scripts
- deleting files
- deployment changes
- unrelated feature work
- committing changes
- fixing independent issues not selected for this run

If the fix requires files outside allowed scope, stop and ask or return to Stage 2.

## Testing Rules

Use the narrowest available validation:
- existing failing test
- reproduction command from `problem-report.md`
- focused unit/integration test
- build/typecheck only when relevant
- newly added regression test only when safe and appropriate

Do not run broad or long-running test suites unless explicitly safe and bounded.

If no validation can be run, record the limitation in `fix-log.md`.

## Escalation Rules

Stop and return to investigation when:
- root cause appears wrong
- focused validation contradicts `problem-report.md`
- required fix is much larger than expected
- database migration is required
- dependency installation is required
- credentials or external services are required
- multiple incompatible fixes are possible
- patch would touch do-not-touch areas
- a second independent bug becomes apparent

## Strict Prohibitions

Do not:
- investigate a new root cause beyond confirming Stage 2 assumptions
- perform broad repository investigation
- install dependencies
- run migrations or seeds
- delete files
- deploy
- start long-running services
- commit changes
- rewrite architecture
- expand scope without explicit user confirmation
- wait passively for free-form user feedback
