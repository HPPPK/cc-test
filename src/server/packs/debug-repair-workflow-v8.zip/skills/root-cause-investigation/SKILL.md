# Root-Cause Investigation

Use this skill only in the investigation stage of a debug workflow.

Purpose:
Establish an evidence-backed root cause before any repair is attempted.

Core rule:
No fixes without evidence-backed root cause.

This skill is not allowed to edit files, apply patches, or propose implementation details beyond a minimal fix direction.

## Guided Interaction Requirement

When user judgment is required, use AskUserQuestion with bounded options. Do not wait passively for the user to type free-form feedback.

Use AskUserQuestion when:
- debug-context.md is missing or not confirmed
- multiple issues are reported and no selected issue is chosen
- investigation scope is non-trivial and not yet confirmed
- reproduction requires user-provided steps, credentials, logs, screenshots, or permissions
- root cause is identified and the workflow needs permission to enter repair
- evidence is insufficient and the workflow must choose whether to continue, return to intake, or stop unresolved

## Investigation Method

Follow this sequence:

1. Read debug-context.md.
2. Confirm the reported symptom, expected behavior, actual behavior, available evidence, affected area, selectedIssueId, and limitations.
3. If the report contains multiple issues, keep issueIds separate and investigate only the selected issueId unless the user explicitly asks to check whether they share one root cause.
4. Reproduce the problem when safe and possible.
5. If reproduction is not possible, document why and collect alternative evidence.
6. Identify investigation lanes.
7. Collect evidence from logs, tests, stack traces, code paths, configs, recent changes, and integration boundaries.
8. Form hypotheses.
9. Test or falsify hypotheses using evidence.
10. Identify the most likely root cause only if evidence supports it.
11. Define a minimal fix strategy without writing code.
12. Ask the user to confirm whether the workflow may enter the repair stage.
13. Decide readyForFix.

## Investigation Lanes

Use only the lanes relevant to the bug:

### reproduction-lane
Confirm the exact command, user action, test, or scenario that produces the failure.

### stacktrace-lane
Analyze errors, logs, stack traces, compiler output, test output, and failing assertions.

### codepath-lane
Trace the relevant execution path from entrypoint to failure point.

### test-signal-lane
Inspect failing tests, related tests, missing tests, and expected behavior implied by tests.

### config-env-lane
Inspect environment variables, config files, ports, paths, dependency versions, platform assumptions, and runtime setup.

### recent-change-lane
Inspect recent diffs, changed files, new dependencies, renamed symbols, and configuration changes when available.

### integration-lane
Inspect boundaries between frontend/backend, database, filesystem, network, external APIs, browser/runtime, or generated assets.

Do not run every lane by default. Choose only the smallest set needed for the evidence.

## Multi-Issue Rules

If the user reports multiple symptoms or bugs:

1. Keep separate issueIds from debug-context.md.
2. Do not merge them into one root cause unless evidence supports a same-root-cause group.
3. Classify relationships as:
   - independent
   - duplicate
   - same-root-cause
   - blocked
   - unclear
4. Stage 3 may repair only one selected issueId or one evidence-backed same-root-cause group at a time.
5. If no issue is selected, ask the user which issue to investigate first.

## Evidence Rules

Every root-cause claim must cite evidence.

Valid evidence includes:
- failing command output
- failing test output
- stack trace
- log message
- code path reference
- config value
- related test assertion
- user-provided reproduction step
- inherited debug context
- observed mismatch between expected and actual behavior

Invalid evidence:
- guessing from file names
- assuming based on common bugs
- inventing missing logs
- claiming a root cause because it "seems likely"
- proposing a fix before investigation

## Ready For Fix Rules

Set readyForFix = true only when:
- the selected issueId or issue group is clear, and
- the symptom is understood, and
- there is enough evidence for a likely root cause, and
- affected files/modules are identified, and
- a minimal fix direction is clear, and
- the user has confirmed entering repair or the workflow explicitly records that confirmation is still required, and
- the fix can be scoped.

Set readyForFix = false when:
- the bug cannot be reproduced and there is no alternative evidence
- the root cause is unknown
- multiple incompatible hypotheses remain
- critical user information is missing
- investigation would require permission not granted
- the user has not approved moving into repair when approval is required
- the issue requires dependency installation, migration, credentials, or external access not approved

## Minimal Fix Strategy Rules

The minimal fix strategy may describe:
- what behavior should change
- which area likely needs modification
- what must not be touched
- what validation should run after the fix

It must not include:
- code patches
- implementation details that belong to the coder stage
- broad rewrites
- unrelated improvements
- dependency installation
- database changes

## Strict Prohibitions

Do not:
- edit files
- apply patches
- dispatch coder subagents
- install dependencies
- run migrations or seeds
- delete files
- deploy
- start long-running services
- make broad rewrites
- claim root cause without evidence
- move to repair when readyForFix is false
- leave the user guessing whether the workflow is waiting, continuing, or finished

This stage is investigation only.
