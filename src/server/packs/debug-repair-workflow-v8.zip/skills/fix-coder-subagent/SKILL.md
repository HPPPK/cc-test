# Fix Coder Subagent

Use this skill only when Stage 3 needs a bounded coder subagent to apply a scoped debug fix.

Purpose:
Apply the smallest code change described by `fix-task-packet.md`.

This is not a general implementation agent.

## When To Use

Use a Coder Subagent when:
- `problem-report.md` has `readyForFix = true`
- root cause is evidence-backed
- one selected issueId or same-root-cause group is in scope
- minimalFixStrategy is clear
- allowed change scope is narrow
- focused validation target exists or limitation is acceptable
- user approved the Fix Scope Gate

Do not use a Coder Subagent when:
- `readyForFix` is false
- rootCause is `Unknown` or `Unresolved`
- affected files are unclear
- fix requires broad design choices
- fix requires dependency install
- fix requires database migration
- fix requires credentials or external service access
- fix requires touching do-not-touch areas
- multiple independent bugs are mixed together

## Coder Task Packet

Every coder subagent must receive:

```markdown
# Debug Fix Task Packet

## Selected Issue
issueId or same-root-cause group.

## Source Problem Report
problem-report.md

## Root Cause
...

## Confidence
high | medium | low

## Allowed Change Scope
- files:
- modules:
- behaviors:

## Do Not Touch
- ...

## Minimal Fix Strategy
...

## Expected Behavior After Fix
...

## Test / Validation Target
- focused failing test:
- reproduction command:
- existing check:
- expected result:

## User Approval
Fix Scope Gate approved: true | false

## Forbidden Actions
- no unrelated refactor
- no broad formatting
- no dependency install
- no migration
- no seed
- no delete
- no deploy
- no commit
- no broad rewrite
- no independent bug fixes

## Escalation Conditions
Return to Stage 3 leader if:
- root cause appears wrong
- fix requires files outside allowed scope
- focused validation contradicts problem-report.md
- dependency install or migration is required
- multiple incompatible fixes are possible
- do-not-touch area must be changed
- another independent bug is discovered
```

## Allowed Actions

The coder subagent may:
- read relevant files
- apply minimal patch within allowed scope
- update or add a focused regression test when safe
- run focused validation if permitted by Stage 3
- return a structured fix result

## Forbidden Actions

The coder subagent must not:
- install dependencies
- run migrations or seeds
- delete files
- deploy
- commit changes
- rewrite architecture
- reformat unrelated files
- modify do-not-touch files
- start long-running services
- create unrelated features
- fix unselected independent issues
- continue after scope contradiction
- wait for passive free-form user feedback

## Required Coder Output

The coder must return:

```markdown
# Coder Fix Result

## Status
completed | blocked | needs-investigation | needs-user-confirmation

## Selected Issue
...

## Files Changed
- path:
- reason:
- scope status: within-scope | deviation

## Summary Of Changes
...

## Validation Run
- command/check:
- result:
- output summary:

## Regression Test Added Or Updated
...

## Scope Deviations
If none, write None.

## Blockers
...

## Limitations
...
```

The Stage 3 leader owns the final `fix-log.md`.
The coder subagent provides implementation evidence only.
