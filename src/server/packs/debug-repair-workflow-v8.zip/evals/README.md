# Debug Workflow Eval Pack

This folder contains lightweight evaluation assets for the guided debug workflow.

These files are packaged inside the ZIP as real files. They are not external links and they are not runtime dependencies.

## Purpose

Use these assets to check whether the workflow keeps the intended behavior:

- user is actively guided with `AskUserQuestion` instead of passive free-form prompting
- multiple reported bugs are split into issue IDs
- Stage 2 investigates root cause before repair
- Stage 3 edits code only after `readyForFix = true` and user confirmation
- Stage 4 validates and asks for preview / finish / continue decision
- Stage 5 ends with an explicit follow-up gate

## Files

- `debug-workflow-eval-cases.json`: structured test cases for prompt/workflow behavior.
- `debug-workflow-eval-rubric.md`: scoring rubric for manual, promptfoo-style, or DeepEval-style checks.
- `pack-static-validator.py`: dependency-free Python validator for ZIP structure, checksums, required skills, and stage gate fields.
- `pack-static-validation-report.md`: validation result generated for this packaged ZIP.

## How to use

Run the static validator from outside the ZIP:

```bash
python evals/pack-static-validator.py path/to/workflow.zip
```

The script does not install dependencies and does not execute workflow stages. It only reads ZIP contents.

For behavioral evaluation, use the JSON cases with your preferred runner. Each case provides:

- input scenario
- expected stage behavior
- expected `AskUserQuestion` behavior
- forbidden behavior
- expected artifacts or fields

These cases are not meant to replace real debugging benchmarks. They are meant to catch regressions in workflow logic and user guidance.
