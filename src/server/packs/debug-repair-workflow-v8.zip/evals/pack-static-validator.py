#!/usr/bin/env python3
"""Dependency-free static validator for guided debug workflow ZIP packs.

Usage:
    python evals/pack-static-validator.py path/to/workflow.zip

This script only reads the ZIP. It does not execute workflow stages, install dependencies,
or call external services.
"""
import sys, zipfile, json, hashlib, re

REQUIRED_SKILLS = [
    "skills/guided-user-checkpoints/SKILL.md",
    "skills/skill-execution-contract/SKILL.md",
    "skills/debug-intake-triage/SKILL.md",
    "skills/root-cause-investigation/SKILL.md",
    "skills/debug-investigator-subagent/SKILL.md",
    "skills/scoped-debug-fix/SKILL.md",
    "skills/fix-coder-subagent/SKILL.md",
    "skills/fix-reviewer-subagent/SKILL.md",
    "skills/debug-quality-validation-gate/SKILL.md",
    "skills/debug-preview-decision-gate/SKILL.md",
    "skills/debug-guided-finish/SKILL.md",
]
REQUIRED_PHASES = [
    "debug-memory-intake",
    "debug-investigate",
    "debug-fix",
    "debug-quality-preview",
    "debug-finish-memory",
]


def sha256(data: bytes) -> str:
    return "sha256-" + hashlib.sha256(data).hexdigest()


def main(path: str) -> int:
    problems = []
    with zipfile.ZipFile(path) as z:
        names = set(z.namelist())
        for required in ["manifest.json", "checksums.json", "permissions/permissions.json", "workflows/debug-repair-workflow-v8.workflow.json"]:
            if required not in names:
                problems.append(f"missing required file: {required}")
        if problems:
            print("FAIL")
            print("\n".join(problems))
            return 1

        manifest = json.loads(z.read("manifest.json"))
        workflow = json.loads(z.read("workflows/debug-repair-workflow-v8.workflow.json"))
        permissions = json.loads(z.read("permissions/permissions.json"))
        checksums = json.loads(z.read("checksums.json"))

        for skill in REQUIRED_SKILLS:
            if skill not in names:
                problems.append(f"missing required packaged skill: {skill}")

        entry_skills = set(manifest.get("entrypoints", {}).get("skills", []))
        for skill in REQUIRED_SKILLS:
            if skill not in entry_skills:
                problems.append(f"skill not listed in manifest entrypoints.skills: {skill}")

        for skill in entry_skills:
            if skill not in names:
                problems.append(f"manifest skill entrypoint does not exist: {skill}")

        file_sums = checksums.get("files", {})
        for name, expected in file_sums.items():
            if name == "checksums.json":
                continue
            if name not in names:
                problems.append(f"checksum listed for missing file: {name}")
                continue
            actual = sha256(z.read(name))
            if actual != expected:
                problems.append(f"checksum mismatch: {name}")

        phase_by_id = {p.get("id"): p for p in workflow.get("phases", [])}
        for pid in REQUIRED_PHASES:
            if pid not in phase_by_id:
                problems.append(f"missing phase: {pid}")

        def text_of_phase(pid):
            p = phase_by_id.get(pid, {})
            return json.dumps(p, ensure_ascii=False).lower()

        checks = [
            ("debug-memory-intake", ["askuserquestion", "debug understanding checkpoint", "issuematrix", "readyforinvestigation"]),
            ("debug-investigate", ["root-cause", "problem-report.md", "readyforfix", "investigator subagent"]),
            ("debug-fix", ["fix-task-packet.md", "fix-log.md", "readyforqualityvalidation", "fix reviewer subagent"]),
            ("debug-quality-preview", ["quality-report.md", "preview", "readyforfinish", "bounded repair"]),
            ("debug-finish-memory", ["handoff.md", "run-report.md", "project-context.md", "askuserquestion"]),
        ]
        for pid, needles in checks:
            blob = text_of_phase(pid)
            for needle in needles:
                if needle not in blob:
                    problems.append(f"phase {pid} missing expected text: {needle}")

        # Permissions sanity check
        perm_phases = {}
        for wf in permissions.get("workflows", []):
            if wf.get("id") == "debug-repair-workflow-v8":
                perm_phases = {p.get("id"): p.get("runtimeContract", {}) for p in wf.get("phases", [])}
                break
        for pid in REQUIRED_PHASES:
            if pid not in perm_phases:
                problems.append(f"permissions missing phase runtimeContract: {pid}")

        if "apply_patch" in perm_phases.get("debug-investigate", {}).get("allowedActions", []):
            problems.append("Stage 2 must not allow apply_patch")
        if "apply_patch" not in perm_phases.get("debug-fix", {}).get("allowedActions", []):
            problems.append("Stage 3 should allow apply_patch for scoped repair")

    if problems:
        print("FAIL")
        for p in problems:
            print("- " + p)
        return 1
    print("PASS")
    print("Static pack validation checks passed.")
    return 0

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python evals/pack-static-validator.py path/to/workflow.zip")
        sys.exit(2)
    sys.exit(main(sys.argv[1]))
