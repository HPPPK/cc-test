# Pack Static Validation Report

Validated ZIP: `workflow-export-1-templates-guided-debug-final-with-evals-skill-contract.zip`

Result: PASS

Checks performed:
- ZIP can be opened.
- workflow JSON is valid.
- manifest JSON is valid.
- permissions JSON is valid.
- checksums.json does not include itself.
- checksums match all listed files.
- manifest skill entrypoints exist as real files inside the ZIP.
- workflow:skill-execution-contract exists as a real packaged skill.
- every phase in `debug-repair-workflow-v8` binds workflow:skill-execution-contract.

No external tools were downloaded or referenced for this pass.

Note: This report was regenerated after applying the stage-local skill execution contract pass. checksums.json intentionally does not include itself.

## Active Interaction Contract Update

This report was regenerated at pack build time to confirm JSON validity, checksums excluding checksums.json itself, real skill entrypoints, and active interaction contract binding for every stage.
