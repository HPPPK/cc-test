# Validation Problem Routing

Use this skill in validation stages when QA, acceptance review, build, lint, test, UI/reference checks, or scenario validation fail.

Purpose:
Route validation failures to the correct next action instead of allowing ad-hoc repair in the validation stage.

## Core Rule

Validation stages do not perform broad repair. They diagnose enough to route the issue, ask the user when needed, and return to the correct stage.

## Failure Categories

Classify each failure as:

- implementation-gap: approved behavior was not implemented or was implemented incorrectly
- scope-ambiguity: acceptance criteria or expected behavior is unclear
- plan-defect: delivery plan or batch split was wrong
- new-bug: failure appears unrelated to the current development task
- environment-blocker: dependency, config, credentials, database, or platform issue blocks validation
- reference-policy-risk: implementation may copy or misuse protected reference material
- ui-visual-mismatch: UI or flow does not match approved direction
- test-infrastructure-issue: tests/checks are broken or missing independently of product behavior
- blocked-unknown: cause is unclear and needs investigation

## Routing Rules

- implementation-gap -> return to Stage 4 scoped implementation.
- scope-ambiguity -> return to Stage 2 scope clarification.
- plan-defect -> return to Stage 3 delivery planning.
- new-bug -> route to Debug workflow.
- environment-blocker -> AskUserQuestion before installing, configuring, or using credentials.
- reference-policy-risk -> return to Stage 2/3 or ask user to adjust reference usage.
- ui-visual-mismatch -> return to Stage 4 for scoped UI repair when scope is clear; otherwise Stage 2/3.
- test-infrastructure-issue -> ask user or return to Stage 3/4 depending on ownership.
- blocked-unknown -> run investigation-only subagent or route to Debug workflow.

## AskUserQuestion Requirement

When the route affects scope, dangerous actions, external dependencies, preview readiness, or risk acceptance, ask the user with bounded options. Do not passively wait for free-form feedback.

Typical options:
1. Return to implementation for scoped fixes.
2. Return to scope/plan to clarify requirements.
3. Route to Debug workflow.
4. Accept documented risk and continue.

## Strict Prohibitions

Do not:
- invoke coder repair directly from validation without a routed decision
- install dependencies without confirmation
- run migrations or seeds without confirmation
- delete files
- deploy
- silently continue to preview with critical failures
- hide not-run scenarios


## Development Validation Problem Routing Gate
If any acceptance, scenario, QA, review, test, build, lint, typecheck, UI/reference, or material-capability validation fails or is blocked, classify it using workflow:validation-problem-routing before deciding the next route. Do not perform broad repair inside validation. Route implementation gaps to Stage 4, scope ambiguity to Stage 2, plan defects to Stage 3, new bugs to Debug workflow, and environment/test-infrastructure blockers to AskUserQuestion or blocked state. Do not proceed to preview while critical validation failures remain unresolved unless the user explicitly accepts documented risk.
