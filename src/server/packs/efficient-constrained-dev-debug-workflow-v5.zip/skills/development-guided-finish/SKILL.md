---
name: Development Guided Finish
referenceId: workflow:development-guided-finish
description: Finalize a Development workflow with explicit finish status, plain-language handoff, and no ambiguous ending.
user-invocable: false
---

# Development Guided Finish

Use this skill only in the final finish stage of a Development workflow.

Purpose:
Create a clear, user-facing completion state after implementation, validation, and preview have completed, been skipped, or been blocked with evidence.

## Required Responsibilities

1. Read the final workflow artifacts before summarizing.
2. Determine finalStatus:
   - completed
   - completed-with-limitations
   - blocked
   - stopped
3. Write a plain-language handoff for non-technical users.
4. Update workflow memory with verified facts only.
5. Record source/reference materials used, UI/UX direction, known visual limitations, known issues, and known risks.
6. Clearly distinguish completed work from pending work.
7. Ask the user for the next action using AskUserQuestion.

## Finish Status Rules

Use completed only when implementation, quality validation, and preview or preview-skip evidence are recorded.

Use completed-with-limitations when the core scope is implemented but some checks, preview steps, or non-critical risks remain documented.

Use blocked when required evidence is missing, validation did not pass, preview failed without accepted risk, or user action is required.

Do not claim completion if quality-report.md or acceptance-review.md is missing.
Do not claim preview passed if run-preview.md does not record it.

## Required Output Evidence

The finish artifacts must record:

- Skill Execution Plan
- finalStatus
- completedScope
- pendingScope
- changedFilesSummary
- validationSummary
- previewSummary
- sourceMaterialsUsed
- uiUxDirectionSummary
- knownVisualLimitations
- knownIssues
- knownRisks
- limitations
- nextWorkflowOptions

## Strict Prohibitions

Do not:
- edit production files
- apply patches
- run tests
- start preview servers
- dispatch coder/reviewer/QA subagents
- install dependencies
- run migrations or seeds
- delete files
- deploy
- commit changes
- auto-start follow-up workflows
- leave the user guessing whether the workflow is done
