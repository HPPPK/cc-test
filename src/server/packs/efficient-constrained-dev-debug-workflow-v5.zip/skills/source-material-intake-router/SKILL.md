# Source Material Intake Router

Use this skill in intake stages that need to identify source materials and determine whether the current model/tools can use them.

## Purpose

Classify user-provided or selected materials before product scope, UI direction, technical planning, or implementation starts.

## Material Types

Recognize:

- plainTextRequirement
- requirementDocument
- expertMaterialPackage
- figmaPrototype
- screenshotOrImage
- htmlPrototype
- referenceWebsite
- existingCode
- codeMigration
- apiDocumentation
- dataFile
- errorLog
- mixedMaterials
- unknown

## Required Output Fields

Produce a materialCapabilitySnapshot with one entry per material:

- materialId
- source
- detectedInputType
- accessStatus
- processingMode
- analyzedStatus
- modelCanUse
- toolCanUse
- limitations

## Rules

Do not treat uploaded, linked, or mentioned material as understood unless it has actually been read or converted into model-usable content.

If a material is inaccessible, needs upload, needs permission, or needs a different model/tool, use AskUserQuestion before continuing when that material affects scope or UI.

Do not infer visual details from screenshots, Figma links, or images unless the active model/tool can actually analyze them.

Do not fetch websites in this workflow stage. A website reference should normally be processed by a reference website expert first, then consumed as an expert material package.
