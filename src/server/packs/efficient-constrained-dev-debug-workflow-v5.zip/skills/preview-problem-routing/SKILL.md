---
name: Preview Problem Routing
referenceId: workflow:preview-problem-routing
description: Route preview failures or user-reported preview issues to the correct prior stage or Debug workflow without repairing inside preview.
user-invocable: false
---

# Preview Problem Routing

Use this skill only when Stage 6 local preview fails or the user reports a problem during preview.

Purpose:
Classify preview issues and route them safely. Stage 6 must not become an ad-hoc repair stage.

## Input Evidence

Collect and record:
- user feedback
- screenshot or description when available
- reproduction steps
- preview URL, route, command, and logs when available
- observed behavior
- expected behavior
- whether the issue blocks finish
- whether the issue is related to the implemented scope

## Routing Categories

### preview-startup-failure
The app cannot start, port conflicts, command missing, runtime crash, or environment issue.
Recommended route: Problem Investigation, Stage 4, Stage 3, or AskUserQuestion depending on evidence.

### product-behavior-issue
The preview runs but the feature behavior does not match acceptance criteria.
Recommended route: Stage 5 if validation was incomplete, Stage 4 if implementation gap is clear, Debug workflow if root cause is unclear.

### visual-or-ux-mismatch
UI does not match confirmed UI/UX direction or reference policy.
Recommended route: Stage 4 for bounded UI correction when within scope, Stage 2/3 if scope or design direction is unclear.

### new-independent-bug
The user reports a bug outside the selected scope.
Recommended route: Debug workflow or new follow-up decision. Do not repair in Stage 6.

### non-blocking-risk
The issue is known, documented, and explicitly accepted by the user.
Recommended route: allow finish only after explicit risk acceptance is recorded.

## Investigation Subagent Rule

If the issue is unclear, code-affecting, cross-module, or may require repair, use a read-only Problem Investigation Subagent before deciding a repair path.

The subagent must return:
- issueSummary
- reproductionSteps
- observedBehavior
- expectedBehavior
- evidence
- rootCause
- affectedFilesOrModules
- severity
- riskLevel
- suggestedRepairPath
- recommendedReturnStage
- needsUserConfirmation
- readyForRepair

## Strict Prohibitions

Do not:
- edit code in Stage 6
- invoke Coder for ad-hoc repair
- apply patches
- run migrations or seeds
- install dependencies
- delete files
- deploy
- silently skip user-reported issues
- claim ready for finish when a blocking issue remains

After any repair outside Stage 6, the workflow must return to Stage 5 validation before rerunning Stage 6 preview.


## Preview Problem Routing Gate
If preview fails or user reports a preview issue, classify it before deciding the route. Use workflow:preview-problem-routing to distinguish implementation gap, plan defect, scope ambiguity, new bug, environment blocker, UI mismatch, and non-blocking risk. Do not repair directly in Stage 6. Ask the user whether to return to implementation, return to scope/plan, route to Debug workflow, accept documented risk, or pause.
