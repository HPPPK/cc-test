# Batched Implementation Execution

Use this skill only in the implementation stage after a confirmed delivery plan and implementation task packets exist.

Purpose:
Execute implementation batches with scoped code changes, structured coder results, read-only reviewer checks, and leader decisions.

This skill is not for brainstorming, scope changes, technical planning, full QA, preview, or final delivery.

## Required Sequence

1. Read work-order.md.
2. Read delivery-plan.md.
3. Read implementation-task-packets.md.
4. Confirm readyForImplementation.
5. Select only batches whose dependencies are satisfied.
6. Dispatch bounded coder subagents or perform bounded leader implementation when appropriate.
7. Collect coder results.
8. Dispatch read-only reviewer subagents for completed batch changes.
9. Decide pass, needs-fix, blocked, needs-user-confirmation, or route-to-problem-investigation.
10. Update implementation-log.md and run-report.md.
11. Set readyForScenarioReview only when all required batches are completed, reviewed, or explicitly skipped with reasons.

## Scope Rules

Implementation may modify only:

- files/modules listed in the current batch allowed scope
- focused tests related to the current behavior
- minimal adjacent files needed to preserve compile/runtime consistency

Implementation must not modify:

- confirmed product scope
- non-goals
- unrelated modules
- unrelated UI direction
- unselected goals or features
- unanalysed source/reference materials
- do-not-touch areas

## Same-Batch Fix Rules

If reviewer finds a small, clear, same-batch issue whose cause is known and whose fix stays inside the current batch scope, the leader may send required fixes back to the coder for that same batch.

Do not use same-batch fixes for:

- unclear failures
- runtime crashes with unknown cause
- cross-module issues
- environment/dependency/database issues
- new bugs
- scope changes
- failures requiring new product decisions

Route those through problem investigation or AskUserQuestion.

## Completion Rules

Stage completion requires:

- implementation-task-packets.md exists
- implementation-log.md exists
- all required batches completed or explicitly skipped with reasons
- every completed batch has coder result and reviewer result
- no unresolved critical or major review issue remains
- targeted validation ran or inability is documented
- dangerous actions were confirmed before execution
- readyForScenarioReview is true

## Strict Prohibitions

Do not:

- use brainstorming
- redo product scope
- redo delivery planning
- perform broad rewrites
- run full QA
- run preview validation
- claim final completion
- auto-start follow-up workflows
