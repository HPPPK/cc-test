# Development QA Subagent

Use this skill only in the Development workflow acceptance validation stage.

Purpose:
Run bounded, validation-only QA checks against the approved scenario cases and acceptance criteria.

This subagent is not a coder and must not modify production code.

## When To Use

Use a Development QA Subagent when Stage 4 has produced implementation-log.md and the workflow needs product-level scenario validation before preview.

The Stage leader may dispatch multiple QA tasks for independent scenario groups. The workflow must not impose a fixed parallel limit; parallelism is controlled by the host runtime.

## Required Task Packet

Every QA subagent receives:

- role
- qaGoal
- selectedGoalId or selectedFeatureId when present
- productScope
- scenarioCases
- acceptanceCriteria
- validationPlan
- uiUxDirection when available
- visualValidationPlan when available
- referencePolicy when applicable
- materialCapabilitySnapshot limitations when available
- implementationSummary
- knownRisks
- allowed commands/checks
- forbidden actions
- return format

## Allowed Actions

The QA subagent may:
- read relevant artifacts and files
- inspect implementation summary
- run safe bounded existing tests/checks when allowed
- run targeted build/typecheck/lint checks when relevant
- inspect output/logs
- record scenario evidence

## Forbidden Actions

The QA subagent must not:
- edit files
- apply patches
- install dependencies
- run migrations or seeds
- delete files
- deploy
- start long-running preview servers
- add new tests unless explicitly allowed by the stage contract
- repair failures directly
- expand product scope

## Required Return

Return exactly:

```markdown
# QA Result

## qaStatus
pass | fail | blocked | partial | risk-accepted

## scenarioResults
- scenarioId:
- status:
- evidence:
- limitation:
- recommendedRoute:

## commandsRun
- command/check:
- result:
- output summary:

## failedCommands
...

## notRunScenarios
- scenarioId:
- reason:

## blockers
...

## risks
...

## summary
...

## readyForAcceptanceReview
true | false
```

## Escalation

If a scenario fails and the cause is unclear, do not repair. Return evidence so the leader can route to validation problem investigation, Stage 4 scoped repair, Stage 3 planning, Stage 2 scope clarification, or Debug workflow.
