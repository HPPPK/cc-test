# Submit Phase Completion Failure Recovery

Use this skill whenever a workflow phase is about to complete or when a phase completion / transition attempt fails.

Purpose:
Prevent the workflow from silently falling through to the next stage, asking the user to type "continue", or executing next-stage actions after `submit_phase_completion` fails.

## Core Rule

A phase boundary is not complete until the runtime has accepted `submit_phase_completion` and created the appropriate pending confirmation, blocked state, or completed/advanced state.

Ordinary assistant text, a written handoff artifact, or a user saying "continue" is not a substitute for a successful phase completion tool call.

## Before Calling submit_phase_completion

Construct the full tool input explicitly:

```json
{
  "status": "ready",
  "handoff": {
    "summary": "What this phase completed",
    "completedItems": [],
    "keyDecisions": [],
    "evidenceArtifacts": [],
    "remainingRisks": [],
    "nextPhaseInputs": []
  },
  "rationale": "Why this phase satisfies its completion criteria",
  "evidence": []
}
```

Rules:
- `status` is required.
- `handoff` is required and must be an object.
- `rationale` is required and must be a non-empty string.
- `evidence` is required and must be an array. Use `[]` when no evidence is available, but explain the limitation in `rationale`.
- Do not assume that a normal chat summary, `handoff.md`, `work-order.md`, `problem-report.md`, or other artifacts automatically become tool parameters.

## Recoverable Failures

If `submit_phase_completion` fails because of missing or malformed arguments, correct the tool input and retry once.

Recoverable examples:
- missing `handoff`
- missing `rationale`
- missing `evidence`
- `handoff` is not an object
- `evidence` is not an array
- stale `stateVersion` when the runtime can refresh the current workflow state

After one corrected retry, if completion still fails, stop and mark the workflow blocked or ask the user with a structured AskUserQuestion.

## Non-Recoverable Failures

Do not retry blindly and do not continue to next-stage actions when:
- `submit_phase_completion` is unavailable
- `request_workflow_route` is unavailable but a non-linear route is required
- the current phase does not match the active runtime phase
- the runtime rejects the route or transition
- the tool is forbidden in the current phase
- the phase transition mechanism is unavailable
- permission or workflow state errors persist after refresh

In these cases:
1. Stop in the current phase.
2. Record `blocked` or `needs_user` status.
3. Explain the blocked reason in user-facing language.
4. Use AskUserQuestion only for safe current-phase choices.

## Forbidden Fallbacks

When phase completion fails, do not:
- ask the user whether to start the next stage
- execute next-stage actions in the current stage
- start implementation from an intake/planning phase
- start validation from an implementation phase before completion is accepted
- start preview before validation completion is accepted
- treat typed "continue" as phase transition
- claim that a non-linear route has happened before runtime approval
- use `submit_phase_completion` as a route tool

## Safe AskUserQuestion Options After Failure

After a completion failure, AskUserQuestion options must stay within the current phase, for example:

1. Retry submitting the current phase completion.
2. View the current phase report or artifact.
3. Adjust the current phase result.
4. Pause or exit the workflow.

Do not offer next-stage actions until the runtime has accepted completion and advanced or routed the workflow.

## Interaction With request_workflow_route

`submit_phase_completion` records phase completion.
`request_workflow_route` requests runtime-approved routing such as advancing, reworking the current phase, jumping to a target phase, pausing, resuming, or finishing.

If a non-linear route is required, call `request_workflow_route` when available. If it is not available, mark the phase blocked/needs_user and do not pretend the route will occur.
