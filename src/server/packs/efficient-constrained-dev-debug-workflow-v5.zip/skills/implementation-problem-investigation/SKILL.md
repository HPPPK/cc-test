# Implementation Problem Investigation

Use this skill only when implementation or review reveals a blocker that cannot be handled as a small same-batch fix.

Purpose:
Route unclear implementation failures to evidence-based investigation instead of letting coder subagents repeatedly guess or patch broadly.

This skill is read-only unless the leader later routes back to a scoped implementation batch.

## Trigger Conditions

Use this skill when:

- reviewer issue is unclear
- failure crosses modules
- runtime crash has unknown cause
- build/test failure is not explained by current batch changes
- environment, dependency, database, migration, seed, generated files, or external service may be involved
- a required fix would exceed allowed scope
- a new bug appears
- acceptance criteria or product scope is ambiguous
- multiple incompatible fixes are possible

Do not use this skill for:

- small same-batch reviewer requiredFix with known cause
- obvious typo/import issue inside allowed scope
- missing user confirmation, where AskUserQuestion is more appropriate

## Investigation Output

Return:

```markdown
# Implementation Problem Investigation Report

## Issue Summary
...

## Trigger
why investigation was needed

## Reproduction / Evidence
...

## Observed Behavior
...

## Expected Behavior
...

## Evidence Checked
...

## Root Cause
Known | Unknown | Unresolved

## Affected Files Or Modules
...

## Risk Level
low | medium | high

## Suggested Repair Path
same-batch-fix | return-to-stage-3-plan | return-to-stage-2-scope | route-to-debug-workflow | ask-user | blocked

## Recommended Return Stage
Stage 2 | Stage 3 | Stage 4 | Debug workflow | AskUserQuestion | Blocked

## Needs User Confirmation
true | false

## Ready For Repair
true | false

## Limitations
...
```

## Strict Prohibitions

Do not:

- edit files
- apply patches
- install dependencies
- run migrations or seeds
- delete files
- deploy
- perform broad rewrites
- continue implementation without leader decision
```
