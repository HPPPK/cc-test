# Guided User Checkpoints

Use this skill when a workflow stage requires user confirmation, missing information recovery, scope approval, or next-step selection.

## Core Rule

Never leave the user guessing what to do next.

When user judgment is needed, use AskUserQuestion with bounded choices instead of passive free-form prompting.

## Required Checkpoint Shape

Each checkpoint should include:

1. Current understanding.
2. Why a decision is needed.
3. Recommended option.
4. 2-4 clear alternatives.
5. What happens after each option.

## Use AskUserQuestion When

- confirming the user's development goal
- choosing among multiple goals or materials
- deciding how to handle unavailable source materials
- approving use of expert material packages
- approving scope or implementation boundaries
- handling model/tool capability limitations
- deciding whether to continue, pause, route to another workflow, or finish

## Do Not

- ask only "please provide more info"
- wait silently for free-form user input
- make the user guess whether the workflow is still running
- continue to detailed scope or planning while critical material access is unresolved
- ask vague open-ended questions when bounded choices are possible

## Stage Boundary Rule

At a stage boundary, record:

- completed work
- current known state
- known limitations
- recommended next action
- whether the workflow is waiting for user confirmation or continuing automatically
