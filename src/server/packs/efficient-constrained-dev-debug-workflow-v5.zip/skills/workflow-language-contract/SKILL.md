# Workflow Language Contract

Use this skill in every user-facing workflow stage.

## Core Rule

Use the configured UI/workflow language for all user-facing prose, AskUserQuestion prompts, option labels, stage summaries, warnings, and handoff explanations.

If no explicit language setting is available, follow the user's current conversation language. In this product context, default to Simplified Chinese for Chinese users.

## Allowed Exceptions

The following may remain in English when appropriate:

- code identifiers
- file paths
- JSON keys
- tool names
- command output
- exact error messages
- third-party package names
- internal workflow ids

## Do Not

Do not randomly switch to English for summaries, questions, option labels, or workflow status.

Do not write mixed Chinese/English UI prose unless the English term is a technical identifier or the user requested English.

## Artifact Language

User-facing artifact sections should use the workflow language.

Machine-readable fields may keep English keys, but their string values should follow the configured language when they are user-facing explanations.


## Language Enforcement Reminder
User-facing status summaries, AskUserQuestion prompts, and option labels must follow the current system/user language setting. In Chinese UI/user context, use Chinese for user-facing workflow interaction. Tool names, file paths, JSON keys, code identifiers, and raw error messages may remain in their original language.
