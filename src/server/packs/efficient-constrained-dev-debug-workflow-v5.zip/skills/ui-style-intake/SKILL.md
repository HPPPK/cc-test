# UI Style Intake

Use this skill only in intake/scope stages when the user provides UI style requirements, visual references, screenshots, prototypes, or asks for a particular look and feel.

## Purpose

Convert natural-language UI preferences into a structured design brief without doing detailed page implementation.

## Required Output Fields

- uiDirectionNeeded
- uiStyleBrief
- surfaceType
- vibeWords
- referenceSignals
- layoutPreference
- visualStrictness
- accessibilityRequirements
- responsiveExpectations
- motionPreference
- copyTone
- mustAvoid
- visualValidationPlan
- selectedDesignSkill
- skillSelectionReason

## Design Skill Selection

Select a design skill only when it is relevant to the task.

Examples:

- landing page / portfolio / aesthetic-heavy redesign -> taste or visual polish skills may be relevant
- dashboard / admin / data table / internal tool -> product UI, accessibility, information architecture, and responsive layout are usually more important than aesthetic-heavy taste skills
- backend/API/documentation task -> skip UI style skills

## Rules

Do not implement UI in this stage.
Do not choose colors, components, animations, or layout details beyond what is needed to preserve user intent for later stages.
Do not copy protected visual assets, exact text, brand, logo, CSS, JS, or source code from reference materials.

## Packaged UI Design Skills

This workflow pack includes two real local UI design skill files:

- `ui:design-taste-frontend` at `skills/vendor/taste-skill/SKILL.md`
- `ui:impeccable` at `skills/vendor/impeccable/SKILL.md`

When the task includes any visible UI surface, visual style request, UI redesign, reference website/screenshot/prototype, landing page, app screen, dashboard, form, onboarding, empty state, or user-facing component, Stage 1 must mark UI design skills as required downstream rather than merely optional.

Default policy for UI tasks:

- Use `ui:design-taste-frontend` to infer aesthetic direction, avoid generic AI UI, set design dials, and define visual must-avoid rules.
- Use `ui:impeccable` to classify brand/product register, define UI quality rules, and plan critique/audit/polish checks.
- For backend-only, CLI-only, data-only, or documentation-only tasks, skip both with a concise reason.

Additional output fields when UI is relevant:

- designRead
- designDials
- impeccableRegister
- selectedUIDesignSkills: [`ui:design-taste-frontend`, `ui:impeccable`]
- uiDesignSkillUseReason
- uiDesignSkillOutputChecklist
