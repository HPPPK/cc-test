# Implementation Task Packet

Use this skill only in the batched implementation stage of a development workflow.

Purpose:
Convert the confirmed delivery-plan.md and work-order.md into bounded per-batch implementation packets before any production code is modified.

This skill is not for product discovery, brainstorming, technical planning, full QA, preview, or final delivery.

## Entry Requirements

Before creating implementation task packets, confirm:

- `.workflow/work-order.md` exists.
- `.workflow/runs/<runId>/delivery-plan.md` exists or the delivery plan section is present in work-order.md.
- `readyForImplementation` is true or the user explicitly approved proceeding with limitations.
- `implementationBatches` exist.
- `batchDependencyGraph` or equivalent dependency notes exist.
- `parallelizableGroups`, conflict boundaries, or integration ordering are recorded.
- dangerous actions requiring confirmation are listed.

If any entry requirement is missing, do not edit code. Ask the user or return to the planning stage.

## Required Output

Write or update `implementation-task-packets.md` before code edits.

It must include:

- Stage-local Skill Execution Plan
- selectedGoalId or confirmed same-scope goal group
- source materials and expert material packages used
- materialCapabilitySnapshot when relevant
- UI/UX direction and reference policy when relevant
- acceptance criteria covered
- scenario cases covered
- implementationBatches
- batchDependencyGraph
- parallelizableGroups
- conflictBoundaries
- integrationOrder
- shared resources and resourceClaims
- per-batch coder task packets
- per-batch reviewer checklists
- problem-routing rules
- dangerousActionsRequiringConfirmation
- focused validation targets
- escalation conditions

## Per-Batch Coder Packet

Every coder packet must include:

- role: coder
- batchId
- goal
- contextSummary
- selectedGoalId or feature/task group
- allowedFilesOrModules
- forbiddenScope
- source/reference constraints when relevant
- UI style constraints when relevant
- acceptance criteria covered
- scenario cases covered
- expectedOutputs
- testsToRun or focused validation target
- dangerousActionsRequiringConfirmation
- returnFormat

## Reviewer Checklist

Every reviewer checklist must include:

- role: reviewer
- batchId
- goal
- allowedReviewScope
- forbiddenActions
- acceptanceCriteriaCovered
- scenarioCasesCovered
- source/reference constraints when relevant
- UI/style constraints when relevant
- expected changed files or modules
- required review output format

## Parallelism Rules

Do not set a fixed maximum parallel subagent count.

The workflow may identify:

- parallelizableGroups
- serialBatches
- dependencies
- writeScopes
- shared resources
- conflictBoundaries
- integrationOrder

The host runtime controls actual parallel execution count.

## Strict Prohibitions

Do not:

- write production code before task packets exist
- invent new implementation batches
- change product scope
- add non-goals back into the product
- ignore material capability limitations
- copy protected reference materials
- install dependencies without user confirmation
- run migrations or seeds without user confirmation
- delete files without user confirmation
- deploy
- start long-running preview servers
- perform full QA or preview
