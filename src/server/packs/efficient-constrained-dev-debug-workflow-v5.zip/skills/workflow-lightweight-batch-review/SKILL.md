---
name: Lightweight Batch Review
referenceId: workflow:lightweight-batch-review
description: Review one completed implementation batch for real blocking defects without expanding into a whole-project audit.
user-invocable: false
---

Use this skill only after the Coder has completed one workflow batch.

1. Read the batch goal, changed-file list, focused test result, and only the files necessary to assess that batch.
2. Check three things: the change stays within scope; the named user behavior is actually supported; and the stated focused evidence is meaningful.
3. Return pass or needs-fix. For a required fix, give a concrete file/behavior/reproduction reason. If evidence is missing, say not run or partial rather than guessing.
4. Add at most one optional improvement. Do not block on style preferences, unrelated cleanup, speculative edge cases, missing broad test suites, or documentation that the batch did not change.
5. Do not edit files, repeat implementation, run unrelated tests, or review unrelated parts of the project.

This is a scoped engineering review, not a release audit. Escalate only genuine blockers or a clear risk to the changed user path.
