# Acceptance Validation Gate

Use this skill only in the Development workflow acceptance validation stage.

Purpose:
Validate that the implemented product behavior satisfies the approved scope, acceptance criteria, scenario cases, reference policy, UI direction, and known constraints before Local Preview.

This skill is not an implementation skill. It must not edit production code.

## Stage-local Skill Rule

Only consider skills declared for the current phase. Do not scan, enumerate, evaluate, or mention every skill packaged in the ZIP. Packaged skills not declared for this phase are out of stage scope.

## Required Inputs

Read these when available:
- `.workflow/work-order.md`
- `.workflow/run-report.md`
- `.workflow/runs/<runId>/delivery-plan.md`
- `.workflow/runs/<runId>/implementation-task-packets.md`
- `.workflow/runs/<runId>/implementation-log.md`

Do not proceed if implementation artifacts are missing, `readyForScenarioReview` is not true, planned batches are incomplete without reasons, or critical batch review issues remain unresolved.

## Validation Scope

Validate only the approved product scope. Focus on:
- acceptance criteria
- scenario cases
- user roles and core flows
- MVP features
- non-goals
- user-facing copy requirements
- UI/UX direction when available
- visual validation plan when available
- reference policy when applicable
- material capability limitations
- dangerous actions or risks recorded earlier

Do not invent unrelated scenarios.
Do not expand the product scope.
Do not add new features.
Do not treat build/lint/typecheck as sufficient proof of product behavior.

## Required Validation Matrix

Create a validation matrix with one row per scenario or acceptance criterion:

- id
- source
- user role or flow
- expected behavior
- check method
- status: pass | fail | not-run | blocked | risk-accepted
- evidence
- limitation
- recommended route if failed

## Reference and UI Validation

If reference materials were used, verify that the implementation follows the allowed reference usage and does not copy protected material.

Check for prohibited copying of:
- exact reference text
- brand names
- logos
- images
- protected icons/assets
- CSS/JS/code
- pricing/customer/legal content

If UI direction exists, validate user-flow and visual intent at a practical level. Do not require pixel-perfect matching unless explicitly required.

## Decision Rules

Set `readyForPreview = true` only when:
- required scenarios are passed or documented as accepted risk
- acceptance criteria are passed or documented as accepted risk
- no critical issue remains unresolved
- no major issue remains unresolved unless user accepted the risk
- reference policy violations are absent or resolved
- Local Preview is safe enough to start

Set `readyForPreview = false` when:
- implementation is incomplete
- critical or major acceptance issue remains
- scenario cases are missing and cannot be derived safely
- validation is blocked
- a new bug or unclear failure needs diagnosis
- user confirmation is required and missing

## User Guidance

When a decision is needed, use AskUserQuestion with bounded choices. Do not passively ask the user to type free-form feedback.

Typical choices:
1. Continue to Local Preview.
2. Return to implementation for scoped fixes.
3. Route unclear failure to problem investigation or Debug workflow.
4. Accept documented risk and continue.

## Strict Prohibitions

Do not:
- edit production code
- apply patches
- dispatch coder subagents directly
- install dependencies
- run migrations or seeds
- delete files
- deploy
- start long-running preview servers
- claim final completion
- perform full preview validation
