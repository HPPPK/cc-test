# Expert Material Package Consumer

Use this skill when a workflow stage receives material packages produced by experts.

## Supported Expert Packages

- website-reference/material.json
- product-brief-intake/material.json
- repo-health-check/material.json
- migration-refactor-assessment/material.json
- other material.json packages with clear sourceType and limitations

## Responsibilities

1. Detect available expert material packages.
2. Ask the user to choose when multiple relevant packages are available.
3. Record selectedMaterialIds, primaryMaterial, secondaryMaterials, and ignoredMaterials.
4. Preserve each package's limitations and materialCapabilitySnapshot.
5. Map package content into the current development workflow without copying protected content.

## Reference Rules

Can reference:

- user flows
- product structure
- interaction patterns
- layout structure
- component organization
- general visual direction
- project structure summaries

Must not copy:

- brand names
- logos
- proprietary images
- exact protected copy
- CSS/JS/source code from reference sites
- pricing/customer/legal content from third parties

## Required Output Fields

- expertMaterialPackages
- selectedMaterialIds
- primaryMaterial
- secondaryMaterials
- ignoredMaterials
- materialUsagePurpose
- referencePolicy
- limitations
