# Route Request Contract

Use this skill in every stage of an active workflow that may continue, rework the current phase, pause, finish, or jump to another phase.

## Core Rule

Stage routing must be represented by runtime-supported workflow route actions, not by ordinary prose.

Ordinary assistant text such as "I will return to Stage 4" does not change workflow state. A stage may only claim a non-linear route after the runtime has either created a pending route or the user has confirmed a server-validated route.

## Runtime Reality

The current runtime has two separate workflow tools:

- `submit_phase_completion`: submit the current phase completion record.
- `request_workflow_route`: request a runtime-validated route.

Do not mix these responsibilities.

## submit_phase_completion

Use `submit_phase_completion` to submit the current phase result.

It must include:

- `status`
- `handoff`
- `rationale`
- `evidence`

It does not jump to an arbitrary phase. It is not the tool for returning to Stage 4, jumping back to investigation, pausing, resuming, or finishing by route decision.

## request_workflow_route

Use `request_workflow_route` when the next action is not simply submitting the current phase result.

Supported route intents:

- `advance`: request the normal next phase.
- `rework_current_phase`: reject/rework the current pending result.
- `jump_to_phase`: request a server-validated jump to a specific phase in the same workflow.
- `pause`: pause the workflow.
- `resume`: resume a paused workflow.
- `finish`: finish the workflow when finishing is valid.

`jump_to_phase` requires `targetPhaseId`.

Do not use this workflow pack to request automatic cross-workflow switching. Cross-workflow routing is not executable by the current runtime. If another workflow is recommended, record it as a manual follow-up recommendation in the handoff or follow-up artifact.

## Runtime Route Request Shape

When `request_workflow_route` is available, use this semantic shape:

```json
{
  "intent": "advance | rework_current_phase | jump_to_phase | pause | resume | finish",
  "targetPhaseId": "required only when intent is jump_to_phase",
  "rationale": "Why this route is needed.",
  "evidence": [],
  "requireUserConfirmation": true
}
```

The runtime may fill or validate `phaseId` and `stateVersion`.

## AskUserQuestion Route Options

When asking the user to choose a route, use structured workflow-route metadata when the host schema supports it:

```json
{
  "id": "return-to-implementation",
  "label": "返回实现阶段处理这个问题",
  "action": {
    "kind": "workflow-route",
    "intent": "jump_to_phase",
    "targetPhaseId": "delegate-implement"
  }
}
```

The visible label is not the route. The executable route is the structured `action` object.

## Handoff Route Fields

Use `recommendedRoute` in `submit_phase_completion.handoff` only as an explanatory record, not as an executable route:

```json
{
  "recommendedRoute": {
    "intent": "jump_to_phase",
    "targetPhaseId": "delegate-implement",
    "reason": "Preview found an implementation gap.",
    "routeExecutable": true,
    "runtimeTool": "request_workflow_route"
  }
}
```

Set `routeExecutable` to true only if `request_workflow_route` is visible and the route has been or will be requested through that tool/protocol.

If recommending another workflow, use a non-executable manual follow-up field:

```json
{
  "recommendedManualWorkflow": {
    "workflowId": "debug-repair-workflow-v8",
    "reason": "A new independent bug was found.",
    "autoStart": false
  }
}
```

## Non-linear Routing Rules

Use non-linear route requests when evidence shows the default next phase is not the right next step.

Examples:

- validation found an implementation gap -> request `jump_to_phase` to the implementation/fix phase.
- validation found wrong root cause -> request `jump_to_phase` to the investigation phase.
- requirements are ambiguous -> request `jump_to_phase` to the scope phase.
- implementation plan is wrong -> request `jump_to_phase` to the delivery/plan phase.
- environment/tooling is unavailable -> use `pause`, `rework_current_phase`, or submit blocked status.
- a new independent bug should use a manual follow-up workflow recommendation, not automatic cross-workflow routing.

Do not say "return to Stage X" in prose while submitting a default linear completion.

## Completion Safety

Before phase completion, verify:

1. The next action matches the latest stage outcome.
2. Any executable non-linear route is requested through `request_workflow_route`.
3. Manual cross-workflow follow-up is clearly marked as non-executable.
4. The visible user-facing choice does not contradict the runtime route target.
5. If route execution is unavailable, finish the current phase as blocked/needs_user; do not perform the target phase's actions inside the current phase.

## Prohibitions

Do not:

- rely on prose to change stages.
- rely on `submit_phase_completion` to jump to arbitrary phases.
- put executable route meaning only inside `handoff` text.
- use the default next stage when the stage outcome requires a non-linear route.
- make the user type "continue" to trigger routing.
- perform target-stage actions before the runtime has actually entered that stage.
- request automatic cross-workflow switching from this ZIP.
