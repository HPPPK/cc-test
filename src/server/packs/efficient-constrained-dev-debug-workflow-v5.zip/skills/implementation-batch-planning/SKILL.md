# Implementation Batch Planning

Use this skill only in the Development workflow delivery-planning stage.

Purpose:
Create small, executable, reviewable implementation batches and Stage 4 coder task packets from confirmed product scope and delivery boundaries.

This skill plans work. It does not implement work.

## Required Batch Fields

Each implementation batch must include:

- batchId
- title
- goal
- dependsOn
- targetModules
- likelyFiles as module or directory-level predictions, not exact patch instructions
- actions
- acceptanceCriteriaCovered
- scenarioCasesCovered
- testsOrChecks
- parallelEligible
- writeScopes
- resourceClaims
- conflictBoundaries
- joinAfter
- stopCondition
- requiresUserConfirmation

## Parallelism Rule

Do not impose a fixed workflow-level parallel limit.

The plan may identify:

- batchDependencyGraph
- parallelizableGroups
- writeScope conflicts
- resourceClaims
- integrationOrder
- joinAfter points

Actual concurrency is controlled by the host runtime.

A batch may be marked parallelEligible only when:

- dependencies are satisfied
- writeScopes do not overlap another ready batch
- resourceClaims do not conflict
- an independent validation signal exists
- integration order is clear

## Coder Task Packets

For each Stage 4 coder packet include:

- role: coder
- batchId
- goal
- allowedFilesOrModules
- forbiddenScope
- inputs
- expectedOutputs
- testsToRun
- returnFormat

Inputs must include only relevant slices of:

- project context
- confirmed product scope
- acceptance criteria
- scenario cases
- UI/UX direction when applicable
- sourceMaterialImplementationNotes
- referencePolicy
- material limitations
- validation expectations

## Reviewer Expectations

Each batch should also define reviewer expectations:

- scope compliance
- acceptance criteria coverage
- source/reference material compliance
- UI direction compliance when applicable
- no forbidden actions
- tests/checks reviewed
- integration risk

## Forbidden Planning Patterns

Do not create batches that:

- mix unrelated features
- reintroduce non-goals
- require unconfirmed migrations or destructive actions
- silently copy protected reference assets or code
- touch broad areas without a clear reason
- depend on unprocessed source materials
- require implementation before user confirmation
- specify exact patch content better left to Stage 4

## Ready For Implementation

Set readyForImplementation = true only when:

- the scope is confirmed
- material limitations are recorded
- implementation batches are small and bounded
- dependency graph and parallelizable groups are clear
- dangerous actions requiring confirmation are listed
- validation plan covers real user scenarios
- user confirmed the delivery plan or explicitly chose to continue with limitations
