# Stage Transition Gate

Use this skill in every workflow phase.

Purpose:
Make phase-to-phase movement explicit, user-visible, and safe. A phase must never finish by silently waiting for arbitrary free-form user input, and it must never perform next-phase actions before the runtime has actually advanced the phase or accepted a route.

## Core Rule

At the end of every non-terminal phase, present a stage transition gate unless the workflow is completed, explicitly exited, paused, or blocked by a fatal runtime error.

The transition gate must use AskUserQuestion with the tool's required top-level `questions` parameter. Do not rely on normal assistant text such as "tell me if you want to continue".

## Required Question Shape

Each stage transition question must include:

1. Current phase name.
2. What was completed.
3. Key artifacts written.
4. Known risks or limitations.
5. The recommended next phase or route, if any, stated in the question body and encoded as structured action metadata.
6. Bounded choices.

Choice labels must be neutral and action-specific. Do not use a label as a hidden action contract.

## Phase Transition Semantics

A user choice such as "enter next phase" means:

- complete the current phase with `submit_phase_completion` when available,
- request runtime phase advancement or routing with `request_workflow_route` when needed,
- resume the workflow in the approved target phase,
- do not perform next-phase actions while still in the current phase.

If `submit_phase_completion`, `request_workflow_route`, or the runtime phase transition mechanism is unavailable for the required action, the workflow must enter a blocked state and explain the missing capability. It must not continue by executing the next phase's implementation, investigation, validation, preview, or finish actions inside the current phase.

## Linear Transition

For a normal default next phase:

1. Use `submit_phase_completion` with complete `status`, `handoff`, `rationale`, and `evidence`.
2. Let the runtime confirmation/advance mechanism enter the next phase.
3. Do not ask the user to type "continue".

## Non-linear Route

For rework, return, jump, pause, resume, or finish by route decision:

1. Use `request_workflow_route` when available.
2. Use structured AskUserQuestion option action metadata for user confirmation when needed.
3. Do not rely on ordinary prose or `handoff` text as the executable route.
4. Do not use cross-workflow automatic routing; record manual follow-up recommendations instead.

## Tool Contract

When `submit_phase_completion` is available, call it with explicit fields:

```json
{
  "status": "ready",
  "handoff": {
    "summary": "What this phase completed.",
    "completedItems": [],
    "keyDecisions": [],
    "evidenceArtifacts": [],
    "remainingRisks": [],
    "nextPhaseInputs": []
  },
  "rationale": "Why this phase satisfies its completion criteria.",
  "evidence": []
}
```

Ordinary prose, stage reports, or handoff artifacts do not automatically become submit_phase_completion arguments. The arguments must be explicit.

## Forbidden

Do not:

- wait for the user to type "continue" in the chat box;
- treat typed "continue" as permission to bypass phase transition;
- execute next-phase actions before runtime phase advancement;
- use next-phase tools before the runtime has actually entered the next phase;
- claim that a non-linear route has happened unless the runtime route tool/protocol has accepted it;
- show or describe a route that contradicts the structured runtime route.
