# Stage-Local Skill Execution Contract

Use this skill to make skill usage explicit and auditable without forcing every stage to consider every packaged skill.

## Core Rule

The ZIP is a skill library. The current stage has a small, curated skill menu.

Do not scan, enumerate, evaluate, or mention all packaged skills in the ZIP.
Skills packaged in the ZIP but not declared for the current phase are out of stage scope and should not be listed as skipped.

## Required Skill Plan

At the start of the stage, create a Skill Execution Plan inside the stage artifact.

The plan must include:

### Required Skills
Skills that must be used in this stage.

### Conditional Skills Triggered
Skills from the current stage menu that became necessary because of the actual task input. Include trigger evidence.

### Optional Skills Skipped
Only list optional skills declared for this stage. Do not list all packaged skills.

### Forbidden Skills / Actions
List stage-relevant forbidden skill categories or actions.

## Required Trace Fields

The stage artifact must include:

- skillsUsed
- skillsSkipped
- triggerEvidence
- skillOutputChecklist
- limitations

## Completion Rule

A stage should not complete unless required skills are accounted for, conditional skills are either triggered or explicitly skipped with a reason, and triggered skills leave their required output fields in the artifact.
