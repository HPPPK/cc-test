# Delivery Plan Boundary Gate

Use this skill only in the Development workflow delivery-planning stage.

Purpose:
Convert confirmed product scope into a bounded delivery plan without implementing code, expanding scope, or asking non-technical users to make unnecessary technology decisions.

## Required Inputs

Read the confirmed artifacts before planning:

- `.workflow/project-context.md`
- `.workflow/work-order.md`
- `.workflow/runs/<runId>/app-framing.md` when available
- `.workflow/runs/<runId>/scope-lock.md` when available
- Stage 1 material/mode gate fields
- Stage 2 product scope, acceptance criteria, scenario cases, UI/UX direction, reference policy, and source material limitations

Do not create a delivery plan if the confirmed scope, acceptance criteria, selected materials, or material limitations are missing. Ask the user or return to Stage 2.

## Stage-Local Skill Menu Rule

Only consider skills declared for the delivery-plan phase. Do not scan or list every packaged skill in the ZIP.

## Planning Responsibilities

Produce a bounded delivery plan containing:

- technicalApproach
- architectureOutline
- modulePlan
- dataPlan
- integrationPlan
- uiImplementationPlan when applicable
- pageRoutePlan when applicable
- componentPlan when applicable
- styleSystemPlan when applicable
- assetPlan when applicable
- interactionStatePlan when applicable
- responsivePlan when applicable
- visualValidationPlan when applicable
- sourceMaterialImplementationNotes when source or expert materials were used
- implementationBatches
- batchDependencyGraph
- parallelizableGroups
- integrationOrder
- conflictBoundaries
- allowedChangeAreas
- doNotTouch
- dangerousActionsNeedingConfirmation
- validationPlan
- rollbackOrRecoveryNotes
- readyForImplementation

## Boundary Rules

Do not:

- write or edit production code
- create source files
- run implementation agents
- run tests or shell commands
- install dependencies
- initialize databases
- run migrations or seed scripts
- delete files
- deploy
- add Stage 2 non-goals back into scope
- invent features not confirmed by the user
- silently choose among conflicting material packages
- copy protected reference-site assets, brand, code, CSS, JS, exact text, or proprietary content

## Reference Material Rules

If expert material packages or source materials were used, the delivery plan must preserve:

- selectedMaterialIds
- primaryMaterial
- secondaryMaterials
- materialCapabilitySnapshot
- referenceUsageMode
- referencePolicy
- feature/product mapping
- limitations

Only plan from materials marked analyzed or usable. If a screenshot, URL, Figma link, PDF, or other material was present but not actually analyzed, record it as a limitation and do not treat it as source of truth.

## UI Planning Rules

If UI direction exists, translate it into implementation constraints, not code:

- pages/routes
- component responsibilities
- layout structure
- interaction states
- visual style constraints
- responsive behavior
- visual validation checks

If UI direction is missing but required for the product, ask the user or return to Stage 2. Do not invent a new visual direction.

## Confirmation Gate

Before entering implementation, present a concise delivery-plan confirmation through AskUserQuestion:

1. Use this recommended technical plan and batch plan (Recommended)
2. Adjust the plan before implementation
3. Pause so I can add technical constraints
4. Return to scope discussion

Do not enter implementation until the plan is confirmed or the user explicitly chooses to continue with recorded limitations.
