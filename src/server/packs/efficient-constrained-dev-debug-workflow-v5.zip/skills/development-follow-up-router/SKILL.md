---
name: Development Follow-up Router
referenceId: workflow:development-follow-up-router
description: Record the user's chosen follow-up route after Development workflow completion without auto-starting another workflow.
user-invocable: false
---

# Development Follow-up Router

Use this skill only in the final finish stage of a Development workflow.

Purpose:
Ask the user what should happen next and record the decision without automatically starting another workflow.

## Required Question Shape

Use AskUserQuestion. Do not rely on passive free-form user feedback.

The question must include:
- current finish status
- validation and preview summary
- known risks or limitations
- recommended option
- alternatives
- what happens after each option

## Standard Options

When the workflow is completed or completed with limitations, offer:

1. End this Development workflow (Recommended)
2. Continue with a Feature Extension workflow
3. Continue with a Debug Repair workflow
4. View the final summary / changed scope / remaining risks

When the workflow is blocked or stopped, offer:

1. Pause and keep the current handoff (Recommended)
2. Return to the appropriate earlier stage
3. Continue with a Debug Repair workflow
4. View blockers and unresolved risks

## follow-up-decision.md

Write a follow-up-decision.md artifact containing:

- finalStatus
- selectedNextAction
- autoStart: false
- recommendedManualWorkflow
- contextToPassForward
- artifactsToReference
- userChoiceSummary
- unresolvedBlockers
- limitations

## Routing Rules

If the user chooses Debug Repair, record nextWorkflowHint = debug-repair and list artifacts to pass forward.

If the user chooses Feature Extension, record nextWorkflowHint = feature-extension and list artifacts to pass forward.

If the user chooses to view the summary, present or open the handoff, but do not change workflow state unless the runtime supports that explicitly.

Never auto-start a follow-up workflow from this skill.
