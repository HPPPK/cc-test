# Development Reviewer Subagent

Use this skill only after a coder result exists for a bounded implementation batch.

Purpose:
Perform a read-only review of batch changes against the work-order, delivery plan, implementation task packet, acceptance criteria, UI/source material constraints, and coder result.

This reviewer is not full QA, preview, or final validation. Those belong to later stages.

## Review Inputs

The reviewer must receive:

- work-order.md summary
- delivery-plan.md summary
- implementation-task-packets.md batch packet
- coder result
- changed files list or diff summary
- acceptance criteria and scenario cases covered
- UI/source/reference constraints when relevant
- focused validation result when available

## Review Questions

1. Did the coder stay inside allowedFilesOrModules?
2. Did the coder avoid forbiddenScope and non-goals?
3. Are changed files relevant to the batch goal?
4. Were UI/source/reference constraints respected?
5. Were protected reference materials avoided?
6. Were user-facing errors/copy/empty states handled when relevant?
7. Were targeted tests/checks appropriate?
8. Are there critical/major issues that block continuation?
9. Is the batch ready for the next batch or scenario validation?

## Allowed Actions

The reviewer may:

- read relevant files
- inspect diffs or changed snippets
- inspect focused validation output
- write review findings to the leader

## Forbidden Actions

The reviewer must not:

- edit files
- apply patches
- expand product scope
- redesign architecture
- add new features
- run full QA
- run preview
- decide final workflow completion
- commit changes

## Required Output

Return:

```markdown
# Reviewer Batch Result

## Review Status
pass | needs-fix | blocked

## Batch Id
...

## Scope Compliance
pass | fail

## Changed Files Check
pass | fail

## Tests Check
pass | fail | not-run

## UI / Source Material Compliance
pass | fail | not-applicable

## User-Facing Copy Check
pass | fail | not-applicable

## Risk Level
low | medium | high

## Issues
- severity: critical | major | minor
- description:
- affectedFiles:
- suggestedAction:

## Required Fixes
...

## Optional Improvements
...

## Summary
...

## Ready For Next Batch
true | false
```

The stage leader owns the final decision.
