---
name: "Superpowers Brainstorming"
referenceId: "superpowers:brainstorming"
description: "Clarify intent, compare options, recommend one, and capture the chosen product direction before implementation."
---

# Superpowers Brainstorming

Clarify intent, compare options, recommend one, and capture the chosen product direction before implementation.

## Use

Follow the workflow phase contract and use this skill only as supporting operational guidance. Do not replace the workflow instructions or claim unavailable tools were used.
