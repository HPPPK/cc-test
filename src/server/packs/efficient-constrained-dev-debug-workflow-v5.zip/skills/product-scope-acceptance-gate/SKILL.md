# Product Scope + Acceptance Gate

Use this skill only in the Development workflow scope stage.

Purpose:
Lock the first-version product scope, user roles, core flows, MVP boundaries, non-goals, acceptance criteria, scenario cases, and user-facing copy expectations before technical planning or implementation.

This skill is a scope gate, not a technical planning skill and not an implementation skill.

## Stage Role

This stage starts after the development intake/material/mode gate has been confirmed.
It consumes route-context, source material summaries, expert material package summaries, UI style notes, and brainstorming mode from Stage 1.

It must not re-ask Stage 1 app framing unless the user explicitly asks to revise it.

## Brainstorming Mode

Brainstorming is controlled by workflow launch configuration and only belongs to this scope stage.

- `brainstormingMode = off`: do not use `superpowers:brainstorming`; extract scope from user request, confirmed route context, and source materials.
- `brainstormingMode = on`: use the packaged original `superpowers:brainstorming` method for guided scope exploration, 2-3 approaches, trade-offs, recommendation, and user approval before scope lock.
- `brainstormingMode = auto`: decide whether to use `superpowers:brainstorming` based on task ambiguity.

Use brainstorming in auto mode when:
- the user gives a vague idea rather than a scoped requirement
- multiple product directions are plausible
- the user asks for ideas or design alternatives
- reference materials exist but the intended usage is unclear
- the MVP boundary is not obvious

Skip brainstorming in auto mode when:
- the user provides a clear PRD, prototype, reference material, or expert material package and says to follow it
- the user gives explicit acceptance criteria or concrete feature scope
- the task is documentation, test, small refactor, or constrained migration scope

When brainstorming is used, the result must be recorded in `.workflow/work-order.md` and `.workflow/runs/<runId>/scope-lock.md`.
Do not allow brainstorming to skip Stage 3 or directly trigger implementation.
Do not commit files from this stage unless the host workflow explicitly allows it.

## Required Scope Outputs

The stage artifact must include:

- Skill Execution Plan
- brainstormingMode
- brainstormingUsed
- resolvedExplorationLevel
- explorationReason
- sourceMaterialSummary
- sourceMaterialFindings when available
- expertMaterialPackageSummary when available
- materialCapabilitySnapshot when applicable
- selectedMaterialIds when applicable
- uiUxDirection when applicable
- uiStyleBrief when applicable
- referencePolicy when applicable
- productScope
- userRoles
- coreUserFlows
- mvpFeatures
- nonGoals
- acceptanceCriteria
- scenarioCases
- userFacingCopyRequirements
- openQuestions
- userConfirmationStatus
- readyForDeliveryPlan
- skillsUsed
- skillsSkipped
- triggerEvidence
- skillOutputChecklist
- limitations

## Acceptance Criteria Rules

Acceptance criteria must be verifiable.
Avoid vague criteria such as "beautiful", "complete", "simple", or "works well" unless they are converted into observable outcomes.

Scenario cases should use Given / When / Then or equivalent user-action structure when possible.

## Reference Material Rules

If reference material is used, record:

- what the reference material contributes
- what can be referenced
- what must be replaced
- what must not be copied
- source material limitations

Do not copy protected brand names, logos, images, exact text, CSS, JavaScript, source code, pricing, customer content, or legal text from reference materials unless the user owns the rights.

## UI Direction Rules

If the product has a visible UI and the user provided UI style requirements or references, convert them into UI/UX direction and visual validation expectations.
Do not create component implementation plans, CSS implementation plans, routes, or target file plans in this stage.

## Strict Prohibitions

Do not:
- edit production files
- create source files
- write implementation batches
- create delivery plans
- choose target files for implementation
- design database schema
- design API routes
- design component structure
- plan CSS implementation details
- invoke coder subagents
- run tests
- install dependencies
- initialize databases
- run migrations or seeds
- delete files
- deploy

This stage locks product scope only.
