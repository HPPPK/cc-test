---
name: Local Preview Feedback Gate
referenceId: workflow:local-preview-feedback-gate
description: Guide a non-technical user through local preview result confirmation without leaving them to guess what to do next.
user-invocable: false
---

# Local Preview Feedback Gate

Use this skill only in the Development workflow local preview stage.

Purpose:
Run a guided user-facing preview checkpoint after implementation and acceptance validation have passed.

This skill is not a testing skill, not a repair skill, and not an implementation skill.

## Required Behavior

1. Confirm preview prerequisites before starting anything.
2. Show the preview URL, route, entry point, test account, and short preview steps when available.
3. Use AskUserQuestion for every user decision.
4. Never ask the user to provide free-form feedback without guided choices.
5. Record the user's selected preview outcome.
6. Record whether the workflow can proceed to finish.

## Required Preview Result Question

After the workflow-owned app has started and the user has had a chance to try it, ask a structured Preview Result Confirmation question.

The question must explain:
- what was started
- where the user should look
- what was already validated
- what remains unverified
- what each choice will do next

The choices must preserve these outcomes:

1. Preview worked, continue to finish. Recommended when no issue is reported.
2. I found a problem. Route to problem handling before finish.
3. Skip preview and record the reason. Use only when the user accepts documented risk.

## Missing Preview Prerequisites

If preview prerequisites are missing, do not start the app. AskUserQuestion with bounded choices such as:

1. Return to fix blocking issues. Recommended.
2. Continue preview with documented risk.
3. Pause and show issue details.

## User Feedback Recording

run-preview.md must record:
- previewStatus
- previewUrl
- previewPort
- previewCommand
- processId when available
- logPath when available
- previewStepsShownToUser
- userPreviewResult
- userFeedbackSummary
- skipReason when skipped
- knownPreviewRisks
- nextStep
- readyForFinish
- limitations

## Strict Prohibitions

Do not:
- edit source files
- apply patches
- run implementation commands
- run migrations or seeds
- install dependencies
- deploy
- repair preview failures directly
- claim preview success after the user reports a blocking issue
- proceed to finish with unresolved blocking preview issues
- use passive free-form prompts like "tell me if anything is wrong"
